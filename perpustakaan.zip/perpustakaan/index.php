<?php
header("location:sub/home.php");
?>