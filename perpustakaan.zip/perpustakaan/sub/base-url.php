<?php
$base_url = 'http://'.$_SERVER['HTTP_HOST'].'/perpustakaan/sub/';
?>