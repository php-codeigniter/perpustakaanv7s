<?php 
session_start();

//untuk "login_multiuser" bisa diganti dan sesuaikan dengan folder project
//tujuan seperti dibuat menggunakan $_SERVER['HTTP_HOST'] agar hostname berubah sendiri secara dinamis

include "base-url.php";

isset ($_GET['app']) ? $app = $_GET['app'] : $app = 'home_index';
?>












<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<title>Sistem Informasi Perpustakaan SMA Negeri 2 Palopo</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<meta name="description" content="Bootstrap 3 template for corporate business" />
	<!-- css -->
	         <link href="http://localhost/perpustakaan/css/bootstrap.min.css" rel="stylesheet" />
                  	<link href="http://localhost/perpustakaan/plugins/flexslider/flexslider.css" rel="stylesheet" media="screen" />
              	<link href="http://localhost/perpustakaan/css/cubeportfolio.min.css" rel="stylesheet" />
	               <link href="http://localhost/perpustakaan/css/style.css" rel="stylesheet" />

	<!-- Theme skin -->
                    	<link id="t-colors" href="http://localhost/perpustakaan/skins/default.css" rel="stylesheet" />

	<!-- boxed bg -->
	                 <link id="bodybg" href="http://localhost/perpustakaan/bodybg/bg1.css" rel="stylesheet" type="text/css" />

	<!-- =======================================================
    Theme Name: Sailor
    Theme URL: https://bootstrapmade.com/sailor-free-bootstrap-theme/
    Author: BootstrapMade
    Author URL: https://bootstrapmade.com
	======================================================= -->

</head>

<body>



	<div id="wrapper">
		<!-- start header -->
		<header>
			<div class="top">
				<div class="container">
					<div class="row">
						<div class="col-md-6">
							<ul class="topleft-info">
							<div class="page-header"><h3><img src="../book1.png" width="50" height="50" /> <a class="font1">Sistem Informasi Perpustakaan</a> <small><b class="font2"></b></small></h3></div>
								<li><i class="fa fa-phone"></i>
                       +62 085 397 685 283</li>
							</ul>
						</div>
						<div class="col-md-6">
							<div id="sb-search" class="sb-search">
								<form>
									<input class="sb-search-input" placeholder="Pencarian..." type="text" value="" name="search" id="search">
									<input class="sb-search-submit" type="submit" value="">
									<span class="sb-icon-search" title="Click to start searching"></span>
								</form>
							</div>


						</div>
					</div>
				</div>
			</div>

			<div class="navbar navbar-default navbar-static-top">
				<div class="container">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
						<a class="navbar-brand" href="index.html"><img src="http://localhost/perpustakaan/img/logo.jpg" alt="" width="199" height="52" /></a>
					</div>
					<div class="navbar-collapse collapse ">
						<ul class="nav navbar-nav">
						<li><a href="home.php">Home</a></li>
							<li class="dropdown active">
							
								<a href="index.php" class="dropdown-toggle " data-toggle="dropdown" data-hover="dropdown" data-delay="0" data-close-others="false">Agen user <i class="fa fa-angle-down"></i></a>
								<ul class="dropdown-menu">
									<li><a href="index.php?app=home_admin">Admin</a></li>
									<li><a href="index.php?app=home_user">User</a></li>

								</ul>

							</li>
							<li class="dropdown">
								<a href="#" class="dropdown-toggle " data-toggle="dropdown" data-hover="dropdown" data-delay="0" data-close-others="false">Berita <i class="fa fa-angle-down"></i></a>
								<ul class="dropdown-menu">
									<li><a href="typography.html">Typography</a></li>
									<li><a href="components.html">Components</a></li>
									<li><a href="pricing-box.html">Pricing box</a></li>
									<li class="dropdown-submenu">
										<a href="#" class="dropdown-toggle " data-toggle="dropdown" data-hover="dropdown">Pages</a>
										<ul class="dropdown-menu">
											<li><a href="fullwidth.html">Full width</a></li>
											<li><a href="right-sidebar.html">Right sidebar</a></li>
											<li><a href="left-sidebar.html">Left sidebar</a></li>
											<li><a href="comingsoon.html">Coming soon</a></li>
											<li><a href="search-result.html">Search result</a></li>
											<li><a href="404.html">404</a></li>
											<li><a href="register.html">Register</a></li>
											<li><a href="login.html">Login</a></li>
										</ul>
									</li>
								</ul>
							</li>
							<li><a href="portfolio.html">Galery</a></li>
							<li><a href="contact.html">Hubungi Kami</a></li>
							<li><a href="index.php?app=about">About</a></li>
								<?php if (isset($_SESSION['nama'])):?>
							<li class="dropdown"><a href="#" class="dropdown-toggle " data-toggle="dropdown" data-hover="dropdown" data-delay="0" data-close-others="false"> <?php echo $_SESSION['nama'];?> <i class="fa fa-angle-down"></i></a>
								<ul class="dropdown-menu">
									<li><a href="logout.php">Logout</a></li>
										<?php else:?>
									<li><a href="app/input_guest.php">Buat Akun</a></li>
									<!--<li><a href="index.php?app=login">Login</a></li>-->	
									<li><a href="http://localhost/perpustakaan/login.php">Login</a></li>	
							<?php endif;?>
								</ul>
							</li>
							
						</ul>
					</div>
				</div>
			</div>
		</header>