
<div id="content">
<?php 	

//menampilkan pesan setelah berhasil login		
if(isset($_SESSION['pesan'])){echo $_SESSION['pesan']; unset($_SESSION['pesan']);}

//cek apakah ada file yang dituju pada direktori app jika tidak ada tampilkan pesan error	
if(file_exists('app/'.$app.'.php')){
	include ('app/'.$app.'.php'); 
}else{
	echo '<div class="well">Error : Aplikasi tidak menemukan adanya file <b>'.$app.'.php </b> pada direktori <b>app/..</b></div>';
}

?>
</div>
