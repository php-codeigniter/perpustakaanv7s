Aplikasi Sistem Informasi Perpustakaan v2.2
Setting:
- login_multiuser/base-url.php
- login_multiuser/cek_login.php
- login_multiuser/app/koneksi.php
- login_multiuser/app/koneksi_buku.php
- login_multiuser/app/koneksi_foto.php
- login_multiuser/app/koneksi_transaksi.php

Butuh bantuan? 08997206535 (WhatsApp Only).