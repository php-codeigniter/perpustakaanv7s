<?php 
session_start();

//untuk "sub" bisa diganti dan sesuaikan dengan folder project
//tujuan seperti dibuat menggunakan $_SERVER['HTTP_HOST'] agar hostname berubah sendiri secara dinamis

include "base-url.php";

isset ($_GET['app']) ? $app = $_GET['app'] : $app = 'home_admin';

?>


 <?php echo 
      include "head_admin.php"?>

                  

   
		
		
		

		  
		  
		  
		  
		  
		  
		  
		  
		     <div class="row">
          <div class="col-lg-12">
            <section class="panel">
              <header class="panel-heading">
                
              </header>
              <div class="panel-body">
                <div class="form">
                  <form class="form-validate form-horizontal " id="register_form" method="get" action="">
                   		
		<?php 	

//menampilkan pesan setelah berhasil login		
if(isset($_SESSION['pesan'])){echo $_SESSION['pesan']; unset($_SESSION['pesan']);}

//cek apakah ada file yang dituju pada direktori app jika tidak ada tampilkan pesan error	
if(file_exists('app/'.$app.'.php')){
	include ('app/'.$app.'.php'); 
}else{
	echo '<div class="well">Error : Aplikasi tidak menemukan adanya file <b>'.$app.'.php </b> pada direktori <b>app/..</b></div>';
}

?>
		

         

          </div>
		  
                  </form>
                </div>
              </div>
            </section>
          </div>
        </div>

  
        <!-- project team & activity end -->

      </section>

    </section>
    <!--main content end-->
  </section>
  <!-- container section start -->

  <!-- javascripts -->
             <script src="http://localhost/perpustakaan/dashboard/js/jquery.js"></script>
         <script src="http://localhost/perpustakaan/dashboard/js/jquery-ui-1.10.4.min.js"></script>
      <script src="http://localhost/perpustakaan/dashboard/js/jquery-1.8.3.min.js"></script>
  <script type="text/javascript" src="http://localhost/perpustakaan/dashboard/js/jquery-ui-1.9.2.custom.min.js"></script>
  <!-- bootstrap -->
       <script src="http://localhost/perpustakaan/dashboard/js/bootstrap.min.js"></script>
  <!-- nice scroll -->
        <script src="http://localhost/perpustakaan/dashboard/js/jquery.scrollTo.min.js"></script>
     <script src="http://localhost/perpustakaan/dashboard/js/jquery.nicescroll.js" type="text/javascript"></script>
  <!-- charts scripts -->
     <script src="http://localhost/perpustakaan/dashboard/assets/jquery-knob/js/jquery.knob.js"></script>
   <script src="http://localhost/perpustakaan/dashboard/js/jquery.sparkline.js" type="text/javascript"></script>
     <script src="http://localhost/perpustakaan/dashboard/assets/jquery-easy-pie-chart/jquery.easy-pie-chart.js"></script>
    <script src="http://localhost/perpustakaan/dashboard/js/owl.carousel.js"></script>
  <!-- jQuery full calendar -->
  <script src="http://localhost/perpustakaan/dashboard/js/fullcalendar.min.js"></script>
    <!-- Full Google Calendar - Calendar -->
      <script src="http://localhost/perpustakaan/dashboard/assets/fullcalendar/fullcalendar/fullcalendar.js"></script>
    <!--script for this page only-->
     <script src="http://localhost/perpustakaan/dashboard/js/calendar-custom.js"></script>
     <script src="http://localhost/perpustakaan/dashboard/js/jquery.rateit.min.js"></script>
    <!-- custom select -->
     <script src="http://localhost/perpustakaan/dashboard/js/jquery.customSelect.min.js"></script>
     <script src="http://localhost/perpustakaan/dashboard/assets/chart-master/Chart.js"></script>

    <!--custome script for all page-->
     <script src="http://localhost/perpustakaan/dashboard/js/scripts.js"></script>
    <!-- custom script for this page-->
      <script src="http://localhost/perpustakaan/dashboard/js/sparkline-chart.js"></script>
     <script src="http://localhost/perpustakaan/dashboard/js/easy-pie-chart.js"></script>
     <script src="http://localhost/perpustakaan/dashboard/js/jquery-jvectormap-1.2.2.min.js"></script>
      <script src="http://localhost/perpustakaan/dashboard/js/jquery-jvectormap-world-mill-en.js"></script>
     <script src="http://localhost/perpustakaan/dashboard/js/xcharts.min.js"></script>
     <script src="http://localhost/perpustakaan/dashboard/js/jquery.autosize.min.js"></script>
     <script src="http://localhost/perpustakaan/dashboard/js/jquery.placeholder.min.js"></script>
    <script src="http://localhost/perpustakaan/dashboard/js/gdp-data.js"></script>
    <script src="http://localhost/perpustakaan/dashboard/js/morris.min.js"></script>
    <script src="http://localhost/perpustakaan/dashboard/js/sparklines.js"></script>
    <script src="http://localhost/perpustakaan/dashboard/js/charts.js"></script>
    <script src="http://localhost/perpustakaan/dashboard/js/jquery.slimscroll.min.js"></script>
	
    <script>
      //knob
      $(function() {
        $(".knob").knob({
          'draw': function() {
            $(this.i).val(this.cv + '%')
          }
        })
      });

      //carousel
      $(document).ready(function() {
        $("#owl-slider").owlCarousel({
          navigation: true,
          slideSpeed: 300,
          paginationSpeed: 400,
          singleItem: true

        });
      });

      //custom select box

      $(function() {
        $('select.styled').customSelect();
      });

      /* ---------- Map ---------- */
      $(function() {
        $('#map').vectorMap({
          map: 'world_mill_en',
          series: {
            regions: [{
              values: gdpData,
              scale: ['#000', '#000'],
              normalizeFunction: 'polynomial'
            }]
          },
          backgroundColor: '#eef3f7',
          onLabelShow: function(e, el, code) {
            el.html(el.html() + ' (GDP - ' + gdpData[code] + ')');
          }
        });
      });
    </script>

</body>

</html>
