<?php echo 

include "header.php";

?>



		<section id="content">


			<!-- divider -->
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="solidline">
						</div>
					</div>
				</div>
			</div>
			<!-- end divider -->

			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="row">
							<div class="col-sm-6 col-lg-6">
								<h4>Sistem Informasi Perpustakaan SMA Negeri 2 Palopo</h4>

								<p>
									
<?php 	

//menampilkan pesan setelah berhasil login		
if(isset($_SESSION['pesan'])){echo $_SESSION['pesan']; unset($_SESSION['pesan']);}

//cek apakah ada file yang dituju pada direktori app jika tidak ada tampilkan pesan error	
if(file_exists('app/'.$app.'.php')){
	include ('app/'.$app.'.php'); 
}else{
	echo '<div class="well">Error : Aplikasi tidak menemukan adanya file <b>'.$app.'.php </b> pada direktori <b>app/..</b></div>';
}

?>
									</p>
							</div>
							<div class="col-sm-6 col-lg-6">
								<h4>Projects</h4>
								<div class="progress">
									<div class="progress-bar progress-bar-success progress-bar-striped active" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 40%">
										40% Complete (success)
									</div>
								</div>
								<div class="progress">
									<div class="progress-bar progress-bar-info progress-bar-striped active" role="progressbar" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100" style="width: 20%">
										20% Complete
									</div>
								</div>
								<div class="progress">
									<div class="progress-bar progress-bar-warning progress-bar-striped active" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%">
										60% Complete (warning)
									</div>
								</div>
								<div class="progress">
									<div class="progress-bar progress-bar-danger progress-bar-striped active" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width: 80%">
										80% Complete
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>

			<!-- divider -->
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="blankline">
						</div>
					</div>
				</div>
			</div>
			<!-- end divider -->




			<!-- divider -->
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="solidline">
						</div>
					</div>
				</div>
			</div>
			<!-- end divider -->



			<!-- divider -->
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="solidline">
						</div>
					</div>
				</div>
			</div>
			<!-- end divider -->

			<!-- clients -->
			<div class="container">
				<div class="row">
					<div class="col-xs-6 col-md-2 aligncenter client">
						<img alt="logo" src="http://localhost/perpustakaan/img/clients/logo1.png" class="img-responsive" />
					</div>

					<div class="col-xs-6 col-md-2 aligncenter client">
						<img alt="logo" src="http://localhost/perpustakaan/img/clients/logo2.png" class="img-responsive" />
					</div>

					<div class="col-xs-6 col-md-2 aligncenter client">
						<img alt="logo" src="http://localhost/perpustakaan/img/clients/logo3.png" class="img-responsive" />
					</div>

					<div class="col-xs-6 col-md-2 aligncenter client">
						<img alt="logo" src="http://localhost/perpustakaan/img/clients/logo4.png" class="img-responsive" />
					</div>

					<div class="col-xs-6 col-md-2 aligncenter client">
						<img alt="logo" src="http://localhost/perpustakaan/img/clients/logo5.png" class="img-responsive" />
					</div>
					<div class="col-xs-6 col-md-2 aligncenter client">
						<img alt="logo" src="http://localhost/perpustakaan/img/clients/logo6.png" class="img-responsive" />
					</div>

				</div>
			</div>

		</section>

		<footer>
			<div class="container">
				<div class="row">
					<div class="col-sm-3 col-lg-3">
						<div class="widget">
							<h4>Get in touch with us</h4>
							<address>
					<strong>Sailor company Inc</strong><br>
					 Sailor suite room V124, DB 91<br>
					 Someplace 71745 Earth </address>
							<p>
								<i class="icon-phone"></i> (123) 456-7890 - (123) 555-7891 <br>
								<i class="icon-envelope-alt"></i> email@domainname.com
							</p>
						</div>
					</div>
					<div class="col-sm-3 col-lg-3">
						<div class="widget">
							<h4>Information</h4>
							<ul class="link-list">
								<li><a href="#">Press release</a></li>
								<li><a href="#">Terms and conditions</a></li>
								<li><a href="#">Privacy policy</a></li>
								<li><a href="#">Career center</a></li>
								<li><a href="#">Contact us</a></li>
							</ul>
						</div>

					</div>
					<div class="col-sm-3 col-lg-3">
						<div class="widget">
							<h4>Pages</h4>
							<ul class="link-list">
								<li><a href="#">Press release</a></li>
								<li><a href="#">Terms and conditions</a></li>
								<li><a href="#">Privacy policy</a></li>
								<li><a href="#">Career center</a></li>
								<li><a href="#">Contact us</a></li>
							</ul>
						</div>
					</div>
					<div class="col-sm-3 col-lg-3">
						<div class="widget">
							<h4>Newsletter</h4>
							<p>Fill your email and sign up for monthly newsletter to keep updated</p>
							<div class="form-group multiple-form-group input-group">
								<input type="email" name="email" class="form-control">
								<span class="input-group-btn">
                            <button type="button" class="btn btn-theme btn-add">Subscribe</button>
                        </span>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div id="sub-footer">
				<div class="container">
					<div class="row">
						<div class="col-lg-6">
							<div class="copyright">
								<p>&copy; Sailor Theme - All Right Reserved</p>
								<div class="credits">
									<!--
                    All the links in the footer should remain intact. 
                    You can delete the links only if you purchased the pro version.
                    Licensing information: https://bootstrapmade.com/license/
                    Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/buy/?theme=Sailor
                  -->
									<a href="https://bootstrapmade.com/bootstrap-business-templates/">Bootstrap Business Templates</a> by <a href="https://bootstrapmade.com/">BootstrapMade</a>
								</div>
							</div>
						</div>
						<div class="col-lg-6">
							<ul class="social-network">
								<li><a href="#" data-placement="top" title="Facebook"><i class="fa fa-facebook"></i></a></li>
								<li><a href="#" data-placement="top" title="Twitter"><i class="fa fa-twitter"></i></a></li>
								<li><a href="#" data-placement="top" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
								<li><a href="#" data-placement="top" title="Pinterest"><i class="fa fa-pinterest"></i></a></li>
								<li><a href="#" data-placement="top" title="Google plus"><i class="fa fa-google-plus"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</footer>
	</div>
	<a href="#" class="scrollup"><i class="fa fa-angle-up active"></i></a>

	<!-- Placed at the end of the document so the pages load faster -->
	<script src="http://localhost/perpustakaan/js/jquery.min.js"></script>
	<script src="http://localhost/perpustakaan/js/modernizr.custom.js"></script>
	<script src="http://localhost/perpustakaan/js/jquery.easing.1.3.js"></script>
	<script src="http://localhost/perpustakaan/js/bootstrap.min.js"></script>
	<script src="http://localhost/perpustakaan/plugins/flexslider/jquery.flexslider-min.js"></script>
	<script src="http://localhost/perpustakaan/plugins/flexslider/flexslider.config.js"></script>
	<script src="http://localhost/perpustakaan/js/jquery.appear.js"></script>
	<script src="http://localhost/perpustakaan/js/stellar.js"></script>
	<script src="http://localhost/perpustakaan/js/classie.js"></script>
	<script src="http://localhost/perpustakaan/js/uisearch.js"></script>
	<script src="http://localhost/perpustakaan/js/jquery.cubeportfolio.min.js"></script>
	<script src="http://localhost/perpustakaan/js/google-code-prettify/prettify.js"></script>
	<script src="http://localhost/perpustakaan/js/animate.js"></script>
	<script src="http://localhost/perpustakaan/js/custom.js"></script>


</body>

</html>
