-- phpMyAdmin SQL Dump
-- version 4.0.9
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 29, 2017 at 04:52 PM
-- Server version: 5.6.14
-- PHP Version: 5.5.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `perpustakaan`
--

-- --------------------------------------------------------

--
-- Table structure for table `buku`
--

CREATE TABLE IF NOT EXISTS `buku` (
  `id_buku` int(100) NOT NULL,
  `judul` varchar(30) NOT NULL,
  `terbit` varchar(30) NOT NULL,
  `penerbit` varchar(30) NOT NULL,
  `halaman` varchar(30) NOT NULL,
  `jumlah` int(100) NOT NULL,
  `peroleh` varchar(30) NOT NULL,
  `tanggal` varchar(30) NOT NULL,
  PRIMARY KEY (`id_buku`),
  KEY `id_buku` (`id_buku`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `buku`
--

INSERT INTO `buku` (`id_buku`, `judul`, `terbit`, `penerbit`, `halaman`, `jumlah`, `peroleh`, `tanggal`) VALUES
(1001, 'Komputer Grafik', '2014', 'Erlangga', '250', 17, 'Gramedia', '19-06-2014'),
(1002, 'Metodologi Penelitian', '2014', 'Erlangga', '250', 19, 'Toko Buku AA', '19-06-2014'),
(1003, 'Multimedia', '2014', 'Erlangga', '300', 16, 'Salemba', '19-06-2014'),
(1004, 'Pemrograman Visual', '2014', 'Erlangga', '300', 26, 'Toko Buku AA', '19-06-2014'),
(1005, 'Sistem Pakar', '2014', 'Erlangga', '250', 32, 'Salemba', '19-06-2014');

-- --------------------------------------------------------

--
-- Table structure for table `kas`
--

CREATE TABLE IF NOT EXISTS `kas` (
  `id_kas` int(100) NOT NULL AUTO_INCREMENT,
  `tgl` varchar(30) NOT NULL,
  `denda` bigint(100) NOT NULL,
  PRIMARY KEY (`id_kas`),
  KEY `id_transaksi` (`id_kas`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE IF NOT EXISTS `transaksi` (
  `id_transaksi` int(100) NOT NULL AUTO_INCREMENT,
  `judul_buku` varchar(250) NOT NULL,
  `id_buku` varchar(30) NOT NULL,
  `nama_peminjam` varchar(100) NOT NULL,
  `id_peminjam` varchar(100) NOT NULL,
  `tgl_pinjam` varchar(15) NOT NULL,
  `tgl_kembali` varchar(15) NOT NULL,
  `status` varchar(10) NOT NULL,
  `ket` varchar(100) NOT NULL,
  PRIMARY KEY (`id_transaksi`),
  KEY `nama_peminjam` (`nama_peminjam`),
  KEY `nama_peminjam_2` (`nama_peminjam`),
  KEY `nama_peminjam_3` (`nama_peminjam`),
  KEY `nama_peminjam_4` (`nama_peminjam`),
  KEY `id_peminjam` (`id_peminjam`),
  KEY `id_buku` (`id_buku`),
  KEY `id_transaksi` (`id_transaksi`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `username` varchar(100) NOT NULL,
  `password` varchar(30) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `jk` varchar(30) NOT NULL,
  `tempat` varchar(30) NOT NULL,
  `lahir` varchar(30) NOT NULL,
  `fakultas` varchar(30) NOT NULL,
  `jurusan` varchar(30) NOT NULL,
  `tahun` varchar(30) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `hp` varchar(30) NOT NULL,
  `foto` varchar(30) NOT NULL,
  `level` enum('admin','user') NOT NULL,
  PRIMARY KEY (`username`),
  KEY `nama` (`nama`),
  KEY `nama_2` (`nama`),
  KEY `nama_3` (`nama`),
  KEY `nama_4` (`nama`),
  KEY `username` (`username`),
  KEY `username_2` (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`username`, `password`, `nama`, `jk`, `tempat`, `lahir`, `fakultas`, `jurusan`, `tahun`, `alamat`, `email`, `hp`, `foto`, `level`) VALUES
('admin', 'admin', 'Admin-Tian', 'L', 'Jakarta', '24-09-1992', 'Fakultas Ilmu Komputer', 'Teknik Informatika S-1', '2011', 'Cikampek', 'septian.fasilkom@gmail.com', '08997206535', '', 'admin'),
('user', 'user', 'User-Tian', 'L', 'Jakarta', '24-09-1992', 'Fakultas Ilmu Komputer', 'Teknik Informatika S-1', '2011', 'Cikampek', 'septian.fasilkom@gmail.com', '08997206535', 'Tianchan Studio.jpg', 'user');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
