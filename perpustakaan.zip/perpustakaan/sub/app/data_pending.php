<?php 
include('koneksi.php');
include('koneksi_transaksi.php');


$query=mysql_query("SELECT * FROM transaksi WHERE status LIKE 'Pending' AND id_peminjam='".$_SESSION['username']."' ORDER BY id_transaksi", $konek);
?>






<?php if($_SESSION['level']!='user'){
echo '<div class="alert alert-error"> Maaf Anda Harus Login sebagai level Admin terlebih dahulu untuk mengakses halaman ini </div>';//jika bukan admin jangan lanjut
die ('');
?>

<?php } ?>










<style>
 table{
  border:silver 1px solid;
 }
 table td{
  border-bottom:silver 1px solid;
  border-right:silver 1px solid;
  padding:0 0 0 5px;
 }
</style>
<table cellpadding="0" cellspacing="0" style="font-family:Verdana, Geneva, sans-serif">
  <!--DWLayoutTable-->
  <tr>
    <td height="25" colspan="7" align="center"><strong>DAFTAR MAHASISWA</strong></td>
  </tr>
  <tr>
    <td height="25" align="center" style="background-color:#CCC"><strong>NO</strong></td>
    <td width="100" align="center" style="background-color:#CCC"><strong>NIS</strong></td>
    <td width="250" align="center" style="background-color:#CCC"><strong>NAMA</strong></td>
    <td width="150" align="center" style="background-color:#CCC"><strong>ALAMAT</strong></td>
    <td width="150" align="center" style="background-color:#CCC"><strong>TGL LAHIR</strong></td>
    <td width="150" align="center" style="background-color:#CCC"><strong>TELEPON</strong></td>
     <td width="100" align="center" style="background-color:#CCC"><strong>ANGKATAN</strong></td>
  </tr>
<?php
$nomor = 1;
while($data = mysql_fetch_array($query)){
$kode = $data['id_transaksi']; // ambil nis siswa (unik)
?>
  <tr>
    <td width="38" height="25" valign="middle"><?php echo $nomor; ?></td>
    <td valign="middle"><?php echo $data['id_transaksi']; ?></td>
    <td valign="middle"><?php echo $data['nama_peminjam']; ?></td>

 <!-- BUAT LINK POP UP KE HALAMAN PDF KONVERTER SEPERTI PADA CONTOH BERIKUT -->
 <a href="javascript:void(0);"
    onclick="window.open('../sub/app/printpdf.php?kode=<?php echo $kode; ?>','nama_window_pop_up','size=800,height=800,scrollbars=yes,resizeable=no')">PDF</a>
 </td>
   </tr>
<?php
$nomor++;
}
?>
</table>










<p><b>Note : </b>Data di atas merupakan data buku yang siap di perpanjang maupun siap data buku yang siap untuk dikembalikan, perpanjangan buku hanya boleh dilakukan 1x, batas waktu peminjaman 7 hari bila lewat dari batas itu akan dikenakan denda sebaesar Rp.500/hari.</p>
</div>







   <script> 
    //options method for call datepicker
	                $('#dp1').datepicker({ format: 'dd-mm-yyyy', autoclose: true, todayHighlight: true})
	                $('#dp2').datepicker({ format: 'dd-mm-yyyy', autoclose: true, todayHighlight: true})
    </script>
		
		
		    <script type="text/javascript" src="<?php echo $base_url;?>asset/js/bootstrap-datepicker2.js"></script>
		

		        <script src="http://localhost/perpustakaan/dashboard/js/jquery.js"></script>
         <script src="http://localhost/perpustakaan/dashboard/js/bootstrap.min.js"></script>
  <!-- nice scroll -->
        <script src="http://localhost/perpustakaan/dashboard/js/jquery.scrollTo.min.js"></script>
         <script src="http://localhost/perpustakaan/dashboard/js/jquery.nicescroll.js" type="text/javascript"></script>

  <!-- jquery ui -->
           <script src="http://localhost/perpustakaan/dashboard/js/jquery-ui-1.9.2.custom.min.js"></script>

  <!--custom checkbox & radio-->
             <script type="text/javascript" src="http://localhost/perpustakaan/dashboard/js/ga.js"></script>
  <!--custom switch-->
         <script src="http://localhost/perpustakaan/dashboard/js/bootstrap-switch.js"></script>
  <!--custom tagsinput-->
        <script src="http://localhost/perpustakaan/dashboard/js/jquery.tagsinput.js"></script>

  <!-- colorpicker -->

  <!-- bootstrap-wysiwyg -->
         <script src="http://localhost/perpustakaan/dashboard/js/jquery.hotkeys.js"></script>
             <script src="http://localhost/perpustakaan/dashboard/js/bootstrap-wysiwyg.js"></script>
               <script src="http://localhost/perpustakaan/dashboard/js/bootstrap-wysiwyg-custom.js"></script>
                <script src="http://localhost/perpustakaan/dashboard/js/moment.js"></script>
               <script src="http://localhost/perpustakaan/dashboard/js/bootstrap-colorpicker.js"></script>
                      <script src="http://localhost/perpustakaan/dashboard/js/daterangepicker.js"></script>
               <script src="http://localhost/perpustakaan/dashboard/js/bootstrap-datepicker.js"></script>
  <!-- ck editor -->
             <script type="text/javascript" src="http://localhost/perpustakaan/dashboard/assets/ckeditor/ckeditor.js"></script>
  <!-- custom form component script for this page-->
              <script src="http://localhost/perpustakaan/dashboard/js/form-component.js"></script>
  <!-- custome script for all page -->
               <script src="http://localhost/perpustakaan/dashboard/js/scripts.js"></script>
