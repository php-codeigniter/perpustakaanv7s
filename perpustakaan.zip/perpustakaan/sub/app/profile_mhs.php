<!DOCTYPE html>
<?php 
include('koneksi.php');
include('koneksi_transaksi.php');
include('transaksi_fungsi.php');

$query=mysql_query("SELECT * FROM transaksi WHERE status LIKE 'Pinjam' AND id_peminjam='".$_SESSION['username']."' ORDER BY id_transaksi", $konek);
?>
<html>
<body>
<?php empty( $app ) ? header('location:../homeuser.php') : '' ; if(isset($_SESSION['level'])){?>

<?php if($_SESSION['level']!='user'){
echo '<div class="alert alert-error"> Maaf Anda Harus Login sebagai level User terlebih dahulu untuk mengakses halaman ini </div>';//jika bukan user jangan lanjut
die ('');
?>

<?php } ?>





        <!-- page start-->
        <div class="row">
          <div class="col-lg-12">
            <section class="panel">
              <header class="panel-heading tab-bg-info">
                <ul class="nav nav-tabs">
                  <li class="active">
                    <a data-toggle="aktive" href="#profile">
                                          <i class="icon-home"></i>
										My Profile
                                      </a>
                  </li>
                 
                </ul>
              </header>
              <div class="panel-body">
                <div class="tab-content">
          
                  <!-- profile -->
                  <div id="profile" class="active">
                    <section class="panel">
					  <?php
    $sql = "SELECT * from user WHERE username='".$_SESSION['username']."'";
    foreach ($dbh->query($sql) as $data) :
	?>	
                      <div class="bio-graph-heading">
                        Selamat Datang di Menu Profile 
                      </div>
                      <div class="panel-body bio-graph-info">
                        <h1>Biodate</h1>
                        <div class="row">
                          <div class="bio-row">
                            <p><span>Name </span>: <?php echo $data['nama'] ?> </p>
                          </div>
                  
                          <div class="bio-row">
                            <p><span>Tanggal Lahir</span>: <?php echo $data['lahir'] ?></p>
                          </div>
                          <div class="bio-row">
                            <p><span>Tempat Lahir </span>: <?php echo $data['tempat'] ?></p>
                          </div>
						  <div class="bio-row">
                            <p><span>Alamat </span>: <?php echo $data['alamat'] ?></p>
                          </div>
                          <div class="bio-row">
                            <p><span>Jenis Kelamin </span>: <?php echo $data['jk'] ?></p>
                          </div>
                          <div class="bio-row">
                            <p><span>Kelas </span><?php echo $data['fakultas'] ?></p>
                          </div>
                          <div class="bio-row">
                            <p><span>Jurusan </span>: <?php echo $data['jurusan'] ?></p>
                          </div>
                          <div class="bio-row">
                            <p><span>Tahun Angkatan </span>: <?php echo $data['tahun'] ?></p>
                          </div>  
						  <div class="bio-row">
                            <p><span>Email </span>: <?php echo $data['email'] ?></p>
                          </div>
                         
						<div class="bio-row">
                            <p><span>Phone </span>: <?php echo $data['hp'] ?></p>
                          </div>

					<div class="bio-row">
                            <p><span>Username </span>: <?php echo $data['username'] ?></p>
                          </div>	
						  
						  <div class="bio-row">
                            <p><span>Password </span>: <?php echo $data['password'] ?></p>
                          </div>						  
						 </div> 
                        </div>
					<!--	<div class="bio-row">
                            <p><span>Photo</span>: 	    <td><img src="foto/<?php echo $data['foto']?>" width="100" height="100"></a></td></p>
                          </div>-->
                        </div>
					<!--	 <div class="bio-row">
                            <p><span>Nama File Foto </span>: <?php echo $data['foto'] ?></p>
                          </div>-->
						 </div>
						
							<?php if($_SESSION['level']=='user'){?>
		<tr class="nowrap">
		<th align="left">Action</th>
			<th> : </th>
			<?php if($_SESSION['level']=='user'){?>
			<th align="left"><a class="btn btn-danger btn-lg"  href="app/edit_guest.php?username=<?php echo $data['username'] ?>"> Edit</a>
			<?php } ?>
		</tr>
			<?php } ?>
						
						
						
						
                      </div>
					  		<?php
    endforeach;
?>
                    </section>
                    <section>
                      <div class="row">
                      </div>
                    </section>
                  </div>
            
                </div>
              </div>
            </section>
          </div>
        </div>







</table>
<p><b>Note : </b>Data di atas merupakan data user profil yang terdaftar dalam sistem perpustakaan, seorang user bisa mengedit profile mereka sendiri, untuk mengupload foto silahkan gunakan menu upload di bawah ini, upload foto sesuai nama foto yang terupdate.</p>
</div>

   <!-- <div style="text-align:justify;"><img src="../foto.png" width="50" height="50" style="float:left; margin:0 9px 3px 0;" /><legend>Upload File Foto</legend></h3>
	<form name="form" enctype="multipart/form-data" action="proses_foto.php" method="POST">
    <input type="hidden" name="MAX_FILE_SIZE" value="10000000" />
	Upload : <input name="file" type="file" style="cursor:pointer;" /><br><br>
    <input type="submit" name="submit" value="Upload" />
    </form>-->

<?php 
}else{
echo '<div class="alert alert-error"> Maaf Anda Harus Login terlebih dahulu untuk mengakses halaman ini </div>';
}
?>
<br>
<div style="text-align:justify;"><img src="../status.png" width="50" height="50" style="float:left; margin:0 9px 3px 0;" /><legend>Status Peminjaman Buku</legend></h3>


    <div class="row">
          <div class="col-md-12">
            <section class="panel">
              <header class="panel-heading">
                <h3>Buttons</h3>

              </header>
              <div class="panel-body">
                <table class="table table-bordered table-striped">

	<thead>
		<tr class="nowrap">
        <tr><td align="left">No</td>
		    <td align="left">Judul Buku</td>
			<td align="left">ID Buku</td>
			<td align="left">Nama Peminjam</td>
			<td align="left">ID Peminjam</td>
			<td align="left">Tgl. Pinjam</td>
			<td align="left">Tgl. Kembali</td>
			<td align="left">Status</td>
			<td align="left">Terlambat</td>
	    </tr>
	</thead>
	<tbody>
<?php
$no=0;
while ($hasil=mysql_fetch_array($query)) {
$no++;
echo "<tr>
	  <td class='td-data'>$no</td>
      <td class='pinggir-data'>$hasil[1]</td>
	  <td class='td-data'>$hasil[2]</td>
	  <td class='td-data'>$hasil[3]</td>
	  <td class='td-data'>$hasil[4]</td>
	  <td class='td-data'>$hasil[5]</td>
	  <td class='td-data'>$hasil[6]</td>
	  <td class='td-data'>$hasil[7]</td>
	  <td class='td-data'>";

	    $tgl_dateline=$hasil['tgl_kembali'];
		$tgl_kembali=date('d-m-Y');
		$lambat=terlambat($tgl_dateline, $tgl_kembali);
		$denda=$lambat*$denda1;
		if ($lambat>0) {
		echo "<font color='red'>$lambat hari<br>(Rp $denda)</font>";
		}
		else {
		echo $lambat." hari";
		}
echo "</td></tr>";
}
?>
</tbody>
</table>
<p><b>Note : </b>Data di atas merupakan status peminjaman buku perpustakaan sebagai pengingat siswa yang sedang meminjam buku perputakaan, perpanjangan buku hanya boleh dilakukan 1x, batas waktu peminjaman 7 hari bila lewat dari batas itu akan dikenakan denda sebaesar Rp.500/hari.</p>
</div>
</div>
</div>
</section>



</body>
</html>