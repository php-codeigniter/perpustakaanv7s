<?php empty( $app ) ? header('location:../homeuser.php') : '' ;?>
<div style="text-align: justify;"><b>Halaman User Perpustakaan</b><br>
<i>Di dalam menu ini seorang user perpustakaan bisa melakukan kegiatan-kegiatan yang bersangkutan dengan pelayanan aplikasi yaitu sebagai berikut : </i></div>
<ul>
<li>Melihat Profil siswa</li>
<li>Mengecek Status Peminjaman Buku</li>
<li>Pesan Buku Online</li>
</ul>
<br><p align="center"><img src="../book4.jpg" width="250" height="250"></br>
<br>

<div style="text-align: justify;"><b>Perhtian !!!</b><br>
<i>Seorang user harus mengikuti peraturuan perpustakaan berikut ini : </i>
<ol>
<li>User hanya diperbolehkan membuat satu akun menggunakan NIS sendiri yang terdaftar dalam lingkungan kampus.</li>
<li>Siswa yang belum terdaftar di Aplikasi tidak diperbolehkan meminjam buku perpustakaan.</li>
<li>Untuk melakukan transaksi peminjaman bisa via online atau  bisa langsung memilih buku di perpustakaan lalu menghampiri admin untuk melakukan transaksi.</li>
<li>Siswa yang terdaftar "User" dapat Mengecek Buku yang tersedia Via Online.</li>
<li>siswa harus tenang di dalam perpustakaan dan jangan membuat kegaduhan.</li>
<li>Bila ada user yang melanggar ketentuan harus siap untuk di delete akun perpustakaan.</li>
</ol>

</div>