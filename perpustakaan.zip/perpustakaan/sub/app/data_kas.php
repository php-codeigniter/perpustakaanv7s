<!DOCTYPE html>
<?php
error_reporting(0);
include('koneksi.php');
include('koneksi_buku.php');
?>

<html>
<body>
<?php empty( $app ) ? header('location:../homeadmin.php') : '' ; if(isset($_SESSION['level'])){ ?>

<?php if($_SESSION['level']!='admin'){
echo '<div class="alert alert-error"> Maaf Anda Harus Login sebagai level Admin terlebih dahulu untuk mengakses halaman ini </div>';//jika bukan admin jangan lanjut
die ('');
?>

<?php } ?>



<div class="row">
          <div class="col-lg-12">
            <section class="panel">
              <header class="panel-heading">
			<p>
	   
		   <a  href="app/input_kas.php" button type="button" class="btn btn-info btn-lg" data-toggle="modal" >Add Kas</button></a>&nbsp;	
</p>
						  
              </header>
			  
			  

              <div class="panel-body">


<div class="tab-content">
    <table class="table table-striped table-advance table-hover">
	<thead>
		<tr class="nowrap">
			<th align="left">ID Kas</th>
			<th align="left">Tanggal Pembayaran</th>
			<th align="left">Denda</th>
			<?php if($_SESSION['level']=='admin'){?>
			<th colspan = "1" align="center">Alat</th>
			<?php } ?>
		</tr>
	</thead>
		<?php
    $sql = "SELECT * FROM kas ORDER BY id_kas";
    foreach ($dbh->query($sql) as $data) :
	?>
	<tbody>
		<tr class="nowrap">
			<td><?php echo $data['id_kas'] ?></td>
			<td><?php echo $data['tgl'] ?></td>
            <td>Rp. <?php echo number_format($data['denda'], 2, ',', '.') ?></td>
			<?php if($_SESSION['level']=='admin'){?>
			<td>
			 <a class="btn btn-danger" href="app/hapus_kas.php?id_kas=<?php echo $data['id_kas'] ?>" class="btn btn-mini" onClick="return confirm('Delete data buku dengan ID : <?php echo $data['id_kas'];?>');""><i class="icon_close_alt2"></i></a>
			</td>
			
			<?php } ?>
		</tr>
<?php
    endforeach;
?>
	</tbody>
</table>

<?php
?>
<table class="table table-bordered table-condensed table-hover" style="width:1px;">
    <tr>
        <td>Jumlah Total</td>
        <td> Rp. 
        <?php
        $qry_jumlah_denda=mysql_query("SELECT SUM(denda) FROM kas");
        $data_denda=mysql_fetch_array($qry_jumlah_denda);
        $jumlah_nilai_denda=$data_denda[0];
        echo number_format($jumlah_nilai_denda, 2, ',', '.');
        ?>
        </td>
    </tr>
</table>

<p>		  
 <a  href="app/pdf_data_kas.php" button type="button" class="btn btn-success btn-lg" data-toggle="modal" >Print</button></a>
</p>
<p><b>Note : </b>Data di atas merupakan data uang kas yang telah tersimpan setelah melakukan proses transaksi bila ada mahasiswa yang dikenakan denda.</p>
</div>

<?php 
}else{
echo '<div class="alert alert-error"> Maaf Anda Harus Login terlebih dahulu untuk mengakses halaman ini </div>';
}
?>
			  
			  
			  
			  
			  
			  
			  
			 </div>
			 
			 
			 
		 

			 </section>
			
			      </section>
          </div>
        </div>
			
</div>






















		        <script src="http://localhost/perpustakaan/dashboard/js/jquery.js"></script>
         <script src="http://localhost/perpustakaan/dashboard/js/bootstrap.min.js"></script>
  <!-- nice scroll -->
        <script src="http://localhost/perpustakaan/dashboard/js/jquery.scrollTo.min.js"></script>
         <script src="http://localhost/perpustakaan/dashboard/js/jquery.nicescroll.js" type="text/javascript"></script>

  <!-- jquery ui -->
           <script src="http://localhost/perpustakaan/dashboard/js/jquery-ui-1.9.2.custom.min.js"></script>

  <!--custom checkbox & radio-->
             <script type="text/javascript" src="http://localhost/perpustakaan/dashboard/js/ga.js"></script>
  <!--custom switch-->
         <script src="http://localhost/perpustakaan/dashboard/js/bootstrap-switch.js"></script>
  <!--custom tagsinput-->
        <script src="http://localhost/perpustakaan/dashboard/js/jquery.tagsinput.js"></script>

  <!-- colorpicker -->

  <!-- bootstrap-wysiwyg -->
         <script src="http://localhost/perpustakaan/dashboard/js/jquery.hotkeys.js"></script>
             <script src="http://localhost/perpustakaan/dashboard/js/bootstrap-wysiwyg.js"></script>
               <script src="http://localhost/perpustakaan/dashboard/js/bootstrap-wysiwyg-custom.js"></script>
                <script src="http://localhost/perpustakaan/dashboard/js/moment.js"></script>
               <script src="http://localhost/perpustakaan/dashboard/js/bootstrap-colorpicker.js"></script>
                      <script src="http://localhost/perpustakaan/dashboard/js/daterangepicker.js"></script>
               <script src="http://localhost/perpustakaan/dashboard/js/bootstrap-datepicker.js"></script>
  <!-- ck editor -->
             <script type="text/javascript" src="http://localhost/perpustakaan/dashboard/assets/ckeditor/ckeditor.js"></script>
  <!-- custom form component script for this page-->
              <script src="http://localhost/perpustakaan/dashboard/js/form-component.js"></script>
  <!-- custome script for all page -->
               <script src="http://localhost/perpustakaan/dashboard/js/scripts.js"></script>
	  
			  
			  
			  