<?php empty( $app ) ? header('location:../index.php') : '' ; ?>





  <div class="panel-group m-bot20" id="accordion">
              <div class="panel panel-default">
                <div class="panel-heading">
                  <h4 class="panel-title">
                                      <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapseOne">
                                         Aplikasi Perpustakaan SMA Negeri 2 Palopo
                                      </a>
                                  </h4>
                </div>
                <div id="collapseOne" class="panel-collapse collapse in">
                  <div class="panel-body">

				  
				  <center>
				  
				  
				  <div style="text-align:justify;"><center><img src="../img/logo.jpg" width="200" height="50" /><br><h3> Aplikasi Perpustakaan SMA Negeri 2 Palopo</h3></br></center></div>
<br>

<b>&trade; Aan Prhatama</b><br>
<i><b>&copy;  <?php echo date('Y'); ?> Aplikasi Sistem Informasi Perpustakaan V4.6. All rights reserved.</b></i><br><br>
<!--<div style="text-align:justify;"><img src="../kontak.jpg" width="50" height="50" style="float:left; margin:0 9px 3px 0;" /><legend><b>Kontak Kami</b></legend></h3>
<i><b>Addres :</b></i><br>
Jl. Perum Pondok Bahagia<br>
Telp : 085397685283
<ul>
<li>(Aan) <a href="https://api.whatsapp.com/send?phone=085397685283">085397685283</a> (WA Only)</li>
</ul>-->

<div style="text-align:justify;"><center><img src="../jam.png" width="50" height="50" style="float:left; margin:0 9px 3px 0;" /><legend><b>Jam Buka Perpustakaan</b></legend></h3>
<i><b>Senin - Jumat :</b></i><br>
<ul>
<li>Buka : 08.00 AM</li>
<li>Istirahat : 12.00 - 13.00 PM</li>
<li>Tutup : 14.00 PM</li>
</ul>
<i><b>Sabtu :</b></i><br>
<ul>
<li>Buka : 08.00 AM</li>
<li>Istirahat : 12.00 - 13.00 PM</li>
<li>Tutup : 14.00 PM</li>
</ul></center>
<!--
<div style="text-align:justify;"><img src="../koleksi.png" width="50" height="50" style="float:left; margin:0 9px 3px 0;" /><legend><b>Koleksi</b></legend></h3>
<div style="text-align: justify;">Untuk koleksi perpustakaan pada sistem ini masih belum lengkap dan dibutuhkan pengembangan untuk meningkatkan koleksi ebook &amp; kumpulan dari ebook yang bermanfaat, untuk kedepannya bisa ditambahkan beberapa fitur lain agar bisa mempermudah pencarian koleksi ebook perpustakaan dan kumpulan ebook jurnal.</div>

<div style="text-align:justify;"><img src="../member.png" width="50" height="50" style="float:left; margin:0 9px 3px 0;" /><legend><b>Member Perpustakaan</b></legend></h3>
<div style="text-align: justify;">Untuk mengakses menu homeuser lalu mengkases koleksi ebook berserta bisa mendownload kumpulan ebook &amp; bisa melakukan transaksi peminjaman buku perpustakaan lalu pada admin silahkan buat akun berdasarkan NPM di menu pendaftaran akun baru.</div>

				  
	-->			  
				  
				  
				  
				  
				  
				  
				  
				  
				  
                  </div>
                </div>
              </div>
              </div>
			  </center>