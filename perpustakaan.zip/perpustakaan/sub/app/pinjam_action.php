<?php
include "koneksi_transaksi.php";
include "kembali_config.php";

$denda		= $_GET['denda'];
$id_trans	= isset($_GET['id_transaksi']) ? $_GET['id_transaksi'] : "";
$judul		= isset($_GET['judul']) ? $_GET['judul'] : "";

if ($id_trans==""||$judul=="") {
	echo '<script type="text/javascript">alert("Pilih dulu buku yang akan dikembalikan.");
	window.location.href="data_transaksi.php";
	</script>';
} else {
	$dates = date('d-m-Y');
	$us=mysql_query("UPDATE transaksi SET status='Pinjam' WHERE id_transaksi='$id_trans'")or die ("Gagal update".mysql_error());
	$uj=mysql_query("UPDATE buku SET jumlah=(jumlah+1) WHERE judul='$judul'")or die ("Gagal update".mysql_error());
	$uk=mysql_query("INSERT INTO kas VALUES ('', '$dates', '$denda')")or die ("Gagal update".mysql_error());

	if ($us || $uj || $uk) {
	echo '<script type="text/javascript">alert("Berhasil Dikembalikan.");
	window.location.href="data_transaksi.php";
	</script>';
	} else {
	echo '<script type="text/javascript">alert("Gagal Dikembalikan.");
	window.location.href="data_transaksi.php";
	</script>';
	}
}
?>