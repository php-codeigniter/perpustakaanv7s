<style>
* {
  box-sizing: border-box;
}

#myInput {
  background-image: url('/css/searchicon.png');
  background-position: 10px 10px;
  background-repeat: no-repeat;
  width: 100%;
  font-size: 16px;
  padding: 12px 20px 12px 40px;
  border: 1px solid #ddd;
  margin-bottom: 12px;
}


</style>


<?php 
include('koneksi.php');
?>

<?php empty( $app ) ? header('location:../homeadmin.php') : '' ; if(isset($_SESSION['level'])){?>

<?php if($_SESSION['level']!='admin'){
echo '<div class="alert alert-error"> Maaf Anda Harus Login sebagai level Admin terlebih dahulu untuk mengakses halaman ini </div>';//jika bukan admin jangan lanjut
die ('');
?>

<?php } ?>

<p>


				  
             <a  href="app/input_user.php" button type="button" class="btn btn-info btn-lg" data-toggle="modal" >Menambah Admin &amp; User Baru</button></a>
	      
</p>


<div class="tab-content">
          <div class="col-lg-12">
            <section class="panel">
			
<input type="text" id="myInput" onkeyup="myFunction()" placeholder="Pencarian.." title="Type in a name">

              <table id="myTable" class="table table-striped table-advance table-hover">
                <tbody>
                  <tr>
                  
                    <th><i class="icon_profile"></i> Username</th>
                    <th><i class="icon_calendar"></i> Password</th>
                    <th><i class="icon_mail_alt"></i> nama</th>
                    <th><i class="icon_pin_alt"></i> JK</th>
                    <th><i class="icon_mobile"></i> Tempat Lahir</th>
                    <th><i class="icon_cogs"></i> Tanggal lahir</th>
                    <th><i class="icon_cogs"></i> Kelas</th>
                    <th><i class="icon_cogs"></i> Jurusan</th>
                    <th><i class="icon_cogs"></i> Tahun Angkatan</th>
                    <th><i class="icon_cogs"></i> Alamat</th>
                    <th><i class="icon_cogs"></i> Email</th>
                    <th><i class="icon_cogs"></i> Ponsel</th>
                  
							               	<?php if($_SESSION['level']=='admin'){?>
                      			  <th><i class="icon_cogs"></i> Action</th>
	                        		<?php } ?>
                  </tr>
				  		<?php
    $sql = "SELECT username, password, nama, jk, tempat, lahir, fakultas, jurusan, tahun, alamat, email, hp FROM user WHERE level=2";
    foreach ($dbh->query($sql) as $data) :
	
	?>
                  <tr>
	         <td><?php echo $data['username'] ?></td>
			<td><?php echo $data['password'] ?></td>
            <td><?php echo $data['nama'] ?></td>
			<td><?php echo $data['jk'] ?></td>
            <td><?php echo $data['tempat'] ?></td>
			<td><?php echo $data['lahir'] ?></td>
			<td><?php echo $data['fakultas'] ?></td>
			<td><?php echo $data['jurusan'] ?></td>
			<td><?php echo $data['tahun'] ?></td>
			<td><?php echo $data['alamat'] ?></td>
			<td><?php echo $data['email'] ?></td>
			<td><?php echo $data['hp'] ?></td>
			<?php if($_SESSION['level']=='admin'){?>
                    <td>
                      <div class="btn-group">
                        <a class="btn btn-primary" href="app/edit_user.php?username=<?php echo $data['username'] ?>"><i class="icon_plus_alt2"></i></a>
                     <!--   <a class="btn btn-success" href="#"><i class="icon_check_alt2"></i></a>-->
                        <a class="btn btn-danger" href="app/hapus_user.php?username=<?php echo $data['username'] ?>" class="btn btn-mini" onClick="return confirm('Delete User dengan ID : <?php echo $data['username'];?>');"><i class="icon_close_alt2"></i></a>
                      </div>
					  			<?php } ?>
                    </td>
                  </tr>
                  <?php
    endforeach;
?>
                </tbody>
              </table>
            </section>
          </div>



<p><b>Note : </b>Data di atas merupakan data user yang terdaftar di dalam sistem perpustakaan, baik itu mendaftar sendiri maupun didaftarkan oleh admin, untuk mengelola data user hanya bisa dilakukan oleh seorang admin dan data user ini berguna untuk proses data transaksi meminjam maupun mengembalikan buku perpustakaan.</p>
</div>
<?php 
}else{
echo '<div class="alert alert-error"> Maaf Anda Harus Login terlebih dahulu untuk mengakses halaman ini </div>';
}
?>

<script>
function myFunction() {
  var input, filter, table, tr, td, i;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
</script>

      <script> 
    //options method for call datepicker
	$('#').datepicker({
         format: 'dd-mm-yyyy',
		 autoclose: true,
		 todayHighlight: true
	})
    </script>
		
		
		    <script type="text/javascript" src="<?php echo $base_url;?>asset/js/bootstrap-datepicker2.js"></script>
		

		        <script src="http://localhost/perpustakaan/dashboard/js/jquery.js"></script>
         <script src="http://localhost/perpustakaan/dashboard/js/bootstrap.min.js"></script>
  <!-- nice scroll -->
        <script src="http://localhost/perpustakaan/dashboard/js/jquery.scrollTo.min.js"></script>
         <script src="http://localhost/perpustakaan/dashboard/js/jquery.nicescroll.js" type="text/javascript"></script>

  <!-- jquery ui -->
           <script src="http://localhost/perpustakaan/dashboard/js/jquery-ui-1.9.2.custom.min.js"></script>

  <!--custom checkbox & radio-->
             <script type="text/javascript" src="http://localhost/perpustakaan/dashboard/js/ga.js"></script>
  <!--custom switch-->
         <script src="http://localhost/perpustakaan/dashboard/js/bootstrap-switch.js"></script>
  <!--custom tagsinput-->
        <script src="http://localhost/perpustakaan/dashboard/js/jquery.tagsinput.js"></script>

  <!-- colorpicker -->

  <!-- bootstrap-wysiwyg -->
         <script src="http://localhost/perpustakaan/dashboard/js/jquery.hotkeys.js"></script>
             <script src="http://localhost/perpustakaan/dashboard/js/bootstrap-wysiwyg.js"></script>
               <script src="http://localhost/perpustakaan/dashboard/js/bootstrap-wysiwyg-custom.js"></script>
                <script src="http://localhost/perpustakaan/dashboard/js/moment.js"></script>
               <script src="http://localhost/perpustakaan/dashboard/js/bootstrap-colorpicker.js"></script>
                      <script src="http://localhost/perpustakaan/dashboard/js/daterangepicker.js"></script>
               <script src="http://localhost/perpustakaan/dashboard/js/bootstrap-datepicker.js"></script>
  <!-- ck editor -->
             <script type="text/javascript" src="http://localhost/perpustakaan/dashboard/assets/ckeditor/ckeditor.js"></script>
  <!-- custom form component script for this page-->
              <script src="http://localhost/perpustakaan/dashboard/js/form-component.js"></script>
  <!-- custome script for all page -->
               <script src="http://localhost/perpustakaan/dashboard/js/scripts.js"></script>

