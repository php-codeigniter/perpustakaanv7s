<?php empty( $app ) ? header('location:../homeadmin.php') : '' ; if(isset($_SESSION['level'])){ ?>

<html>
<head>
</head>
<body>

<?php if($_SESSION['level']!='admin'){
echo '<div class="alert alert-error"> Maaf Anda Harus Login sebagai level Admin terlebih dahulu untuk mengakses halaman ini </div>';//jika bukan admin jangan lanjut
die ('');
?>

<?php } ?>

    <div style="text-align:justify;"><img src="../pdf.png" width="50" height="50" style="float:left; margin:0 9px 3px 0;" /><legend>Upload File Ebook PDF</legend></h3>
    Ukuran File Maksimal : 25 MB.
    <form name="form" enctype="multipart/form-data" action="proses_ebook.php" method="POST">
    <input type="hidden" name="MAX_FILE_SIZE" value="25000000000000000000" />
    Pilih File : <input name="file" type="file" accept="application/pdf" style="cursor:pointer;" required/><br><br>

		<p>
			Fakultas<br />
			<select type="text" name="fakultas" required>
		   	<option selected disabled>Pilih Fakultas</option>		
			<option value="hukum">Fakultas Hukum</option>
			<option value="teknik">Fakultas Teknik</option>
			<option value="ekonomi">Fakultas Ekonomi</option>
			<option value="fai">Fakultas Agama Islam</option>
			<option value="it">Fakultas Ilmu Komputer</option>
			<option value="sosial">Fakultas Ilmu Sosial dan Ilmu Politik</option>
			<option value="pendidikan">Fakultas Keguruan dan Ilmu Pendidikan</option>
			<option value="pertanian">Fakultas Pertanian</option>
			</select>
		</p>

    <input type="submit" name="submit" value="Upload" />
    </form>
	
<br>

    <div style="text-align:justify;"><img src="../rar.png" width="50" height="50" style="float:left; margin:0 9px 3px 0;" /><legend>Upload Kumpulan File Ebook RAR/ZIP</legend></h3>
    Ukuran File Maksimal : 50 MB.
    <form name="form" enctype="multipart/form-data" action="proses_kumpulan.php" method="POST">
    <input type="hidden" name="MAX_FILE_SIZE" value="5000000000000000000" />
    Pilih File : <input name="file" type="file" accept=".zip,.rar" style="cursor:pointer;" required/><br><br>
	
		<p>
			Fakultas<br />
			<select type="text" name="fakultas" required>
		   	<option selected disabled>Pilih Fakultas</option>		
			<option value="hukum">Fakultas Hukum</option>
			<option value="teknik">Fakultas Teknik</option>
			<option value="ekonomi">Fakultas Ekonomi</option>
			<option value="fai">Fakultas Agama Islam</option>
			<option value="it">Fakultas Ilmu Komputer</option>
			<option value="sosial">Fakultas Ilmu Sosial dan Ilmu Politik</option>
			<option value="pendidikan">Fakultas Keguruan dan Ilmu Pendidikan</option>
			<option value="pertanian">Fakultas Pertanian</option>
			</select>
		</p>
		
    <input type="submit" name="submit" value="Upload" />
    </form>

<?php 
}else{
echo '<div class="alert alert-error"> Maaf Anda Harus Login terlebih dahulu untuk mengakses halaman ini </div>';
}
?>
</body>
</html>
