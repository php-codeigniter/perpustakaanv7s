<?php 
session_start();

//untuk "login_multiuser" bisa diganti dan sesuaikan dengan folder project
//tujuan seperti dibuat menggunakan $_SERVER['HTTP_HOST'] agar hostname berubah sendiri secara dinamis

include "../base-url.php";

isset ($_GET['app']) ? $app = $_GET['app'] : $app = 'user';

?>

<?php
$pinjam		= date("d-m-Y");
$seminggu	= mktime(0,0,0,date("n"),date("j")+7,date("Y"));
$kembali  	= date("d-m-Y", $seminggu);
?>

<?php  include "head_user.php"?>


<?php if($_SESSION['level']!='user'){
echo '<div class="alert alert-error"> Maaf Anda Harus Login sebagai level user terlebih dahulu untuk mengakses halaman ini </div>';//jika bukan admin jangan lanjut
die ('');
?>

<?php } ?>


     <div class="row">
          <div class="col-lg-12">
            <section class="panel">
              <header class="panel-heading">
							  <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Form Transaksi Peminjaman</button>
						  
              </header>
			  
			  

              <div class="panel-body">
			
			            <form class="form-validate form-horizontal"  action="input_transaksi_action_siswa.php" method="post">
						<input type="hidden" name="pinjam" value="<?php echo $pinjam; ?>">
						<input type="hidden" name="kembali" value="<?php echo $kembali; ?>">					
					 <div class="form-group">
                    <label class="control-label col-lg-2" for="inputSuccess">Data Peminjam</label>
                    <div class="col-lg-10">
                      <select type="text" name="peminjam" class="form-control input-lg m-bot15" >
					  		    <option value="" selected>NIS &amp; Nama Peminjam </option>
								

								<?php
				include "koneksi_transaksi.php";
				$qa=mysql_query("SELECT * from user WHERE username='".$_SESSION['username']."'", $konek);
				while ($peminjam=mysql_fetch_array($qa)) {
                echo "<option value='$peminjam[0].$peminjam[2]'>$peminjam[0]. $peminjam[2]</option>";
				}
				?>                     
                       </select>                   
                    </div>
                  </div>
				  
				  
				   <div class="form-group">
                    <label class="control-label col-lg-2" for="inputSuccess">Judul Buku</label>
                    <div class="col-lg-10">
                      <select type="text" name="buku" class="form-control input-lg m-bot15" >
					  		    <option value="" selected>Pilih Judul Buku </option>
								
				<?php
					include "koneksi_transaksi.php";
					$q=mysql_query("SELECT * FROM buku ORDER BY id_buku", $konek);
					while ($buku=mysql_fetch_array($q)) {
					echo "<option value='$buku[0].$buku[1]'>$buku[0]. $buku[1]</option>";
					}
					?>                    
                       </select>                   
                    </div>
                  </div>

					     <div class="form-group">
                        <label class="control-label col-sm-4">Tanggal Pinjam</label>
                        <div class="col-sm-6">
                          <input type="text" name="pinjam" value="<?php echo $pinjam ?>" size="16" class="form-control" >
                        </div>
                      </div>
					  
					   <div class="form-group">
                        <label class="control-label col-sm-4">Tanggal Kembali</label>
                        <div class="col-sm-6">
                          <input type="text" name="kembali"  value="<?php echo $kembali?>" size="16" class="form-control" >
                        </div>
                      </div>
					
							
				  <div class="form-group">
                          <label class="control-label col-sm-2">Keterangan</label>
                          <div class="col-sm-10">
                            <textarea class="form-control ckeditor" name="ket" rows="6"></textarea>
                          </div>
                        </div>

                    <div class="form-group">
                      <div class="col-lg-offset-2 col-lg-10">
                        <button class="btn btn-primary" type="submit">Save</button>
                        <button class="btn btn-primary" type="reset" value="Reset" onclick="return confirm('Reset data yang telah dimasukan?')">Reset</button>
                         <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                      </div>
                    </div>
                  </form>
			 </div>
			 
			 
			 
		 

			 </section>
			
			      </section>
          </div>
        </div>
















   <script> 
    //options method for call datepicker
	                $('#dp1').datepicker({ format: 'dd-mm-yyyy', autoclose: true, todayHighlight: true})
	                $('#dp2').datepicker({ format: 'dd-mm-yyyy', autoclose: true, todayHighlight: true})
    </script>
		
		
		    <script type="text/javascript" src="<?php echo $base_url;?>asset/js/bootstrap-datepicker2.js"></script>
		

		        <script src="http://localhost/perpustakaan/dashboard/js/jquery.js"></script>
         <script src="http://localhost/perpustakaan/dashboard/js/bootstrap.min.js"></script>
  <!-- nice scroll -->
        <script src="http://localhost/perpustakaan/dashboard/js/jquery.scrollTo.min.js"></script>
         <script src="http://localhost/perpustakaan/dashboard/js/jquery.nicescroll.js" type="text/javascript"></script>

  <!-- jquery ui -->
           <script src="http://localhost/perpustakaan/dashboard/js/jquery-ui-1.9.2.custom.min.js"></script>

  <!--custom checkbox & radio-->
             <script type="text/javascript" src="http://localhost/perpustakaan/dashboard/js/ga.js"></script>
  <!--custom switch-->
         <script src="http://localhost/perpustakaan/dashboard/js/bootstrap-switch.js"></script>
  <!--custom tagsinput-->
        <script src="http://localhost/perpustakaan/dashboard/js/jquery.tagsinput.js"></script>

  <!-- colorpicker -->

  <!-- bootstrap-wysiwyg -->
         <script src="http://localhost/perpustakaan/dashboard/js/jquery.hotkeys.js"></script>
             <script src="http://localhost/perpustakaan/dashboard/js/bootstrap-wysiwyg.js"></script>
               <script src="http://localhost/perpustakaan/dashboard/js/bootstrap-wysiwyg-custom.js"></script>
                <script src="http://localhost/perpustakaan/dashboard/js/moment.js"></script>
               <script src="http://localhost/perpustakaan/dashboard/js/bootstrap-colorpicker.js"></script>
                      <script src="http://localhost/perpustakaan/dashboard/js/daterangepicker.js"></script>
               <script src="http://localhost/perpustakaan/dashboard/js/bootstrap-datepicker.js"></script>
  <!-- ck editor -->
             <script type="text/javascript" src="http://localhost/perpustakaan/dashboard/assets/ckeditor/ckeditor.js"></script>
  <!-- custom form component script for this page-->
              <script src="http://localhost/perpustakaan/dashboard/js/form-component.js"></script>
  <!-- custome script for all page -->
               <script src="http://localhost/perpustakaan/dashboard/js/scripts.js"></script>