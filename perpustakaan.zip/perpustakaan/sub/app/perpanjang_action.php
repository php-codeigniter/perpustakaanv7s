<?php
$id_transaksi	= isset($_GET['id_transaksi']) ? $_GET['id_transaksi'] : "";
$judul			= isset($_GET['judul']) ? $_GET['judul'] : "";
$tgl_kembali	= isset($_GET['kembali']) ? $_GET['kembali'] : "";
$lambat			= isset($_GET['lambat']) ? $_GET['lambat'] : "";

if($lambat > 7) {
	echo '<script type="text/javascript">alert("Buku yang dipinjam tidak dapat diperpanjang, karena sudah terlambat lebih dari 7 hari. Kembalikan dahulu, kemudian pinjam kembali.");
	window.location.href="data_transaksi.php";
	</script>';
	} else {
	include "koneksi_transaksi.php"; 

	$pecah			= explode("-",$tgl_kembali);
	$next_7_hari	= mktime(0,0,0,$pecah[1],$pecah[0]+7,$pecah[2]);
	$hari_next		= date("d-m-Y", $next_7_hari);

	$update_tgl_kembali=mysql_query("UPDATE transaksi SET tgl_kembali='$hari_next' AND status='Pinjam' WHERE id_transaksi='$id_transaksi'");

	if ($update_tgl_kembali) {
	echo '<script type="text/javascript">alert("Berhasil diperpanjang.");
	window.location.href="data_transaksi.php";
	</script>';
	} else {
	echo '<script type="text/javascript">alert("Gagal diperpanjang.");
	window.location.href="data_transaksi.php";
	</script>';
	}
}
?>