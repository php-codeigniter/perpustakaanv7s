
<?php 
             include('koneksi.php');
?>

<?php empty( $app ) ? header('location:../homeadmin.php') : '' ; if(isset($_SESSION['level'])){?>

<?php if($_SESSION['level']!='admin'){
echo '<div class="alert alert-error"> Maaf Anda Harus Login sebagai level Admin terlebih dahulu untuk mengakses halaman ini </div>';//jika bukan admin jangan lanjut
die ('');
?>

<?php } ?>

<p>
	   
		   <a  href="homeupdate.php" button type="button" class="btn btn-info btn-lg" data-toggle="modal" >Menajement Data Admin</button></a>&nbsp;	
		   <a  href="homeupdate.php" button type="button" class="btn btn-info btn-lg" data-toggle="modal" >Pengguna</button></a>
</p>

<div class="tab-content">





          <div class="col-lg-12">
            <section class="panel">
              <header class="panel-heading">
               Data Admin
              </header>

              <table class="table table-striped table-advance table-hover">
                <tbody>
				<?php
    $sql = "SELECT username, nama, tempat, lahir, alamat, email, hp FROM user WHERE level=1";
	foreach ($dbh->query($sql) as $data) :
    ?>
                  <tr>
                    <th><i class="icon_profile"></i> User</th>
                    <th><i class="icon_calendar"></i> Nama</th>
                    <th><i class="icon_mail_alt"></i> Tempat</th>
                    <th><i class="icon_pin_alt"></i> Lahir</th>
                    <th><i class="icon_mobile"></i> Alamat</th>
                    <th><i class="icon_cogs"></i> Email</th>
                    <th><i class="icon_cogs"></i> Handphone</th>
                  
							               	<?php if($_SESSION['level']=='admin'){?>
                      			  <th><i class="icon_cogs"></i> Action</th>
	                        		<?php } ?>
                  </tr>
                  <tr>
            			<td><?php echo $data['username'] ?></td>
            <td><?php echo $data['nama'] ?></td>
            <td><?php echo $data['tempat'] ?></td>
			<td><?php echo $data['lahir'] ?></td>
			<td><?php echo $data['alamat'] ?></td>
			<td><?php echo $data['email'] ?></td>
			<td><?php echo $data['hp'] ?></td>
			<?php if($_SESSION['level']=='admin'){?>
                    <td>
                      <div class="btn-group">
                        <a class="btn btn-primary" href="app/edit_admin.php?username=<?php echo $data['username'] ?>"><i class="icon_plus_alt2"></i></a>
                        <a class="btn btn-success" href="#"><i class="icon_check_alt2"></i></a>
                        <a class="btn btn-danger" href="app/hapus_user_admin.php?username=<?php echo $data['username'] ?>" class="btn btn-mini" onClick="return confirm('Delete mahasiswa dengan ID : <?php echo $data['username'];?>');"><i class="icon_close_alt2"></i></a>
                      </div>
					  			<?php } ?>
                    </td>
                  </tr>
                  <?php
    endforeach;
?>
                </tbody>
              </table>
            </section>
          </div>




























<p><b>Note : </b>Data di atas merupakan data admin yang terdaftar di dalam PhpMyadmin yang telah memiliki izin dari kepala perpustakaan untuk mengelola aplikasi ini, untuk mengelola CRUD data admin silahkan kunjungin control panel PhpMyadmin dan cari database "project_perpustakaan" dengan tabel "user", cari user dengan level admin untuk mengelola data admin, lalu fungsi edit &amp; hapus bisa klik pada menu tabel.</p>
</div>
<?php 
}else{
echo '<div class="alert alert-error"> Maaf Anda Harus Login terlebih dahulu untuk mengakses halaman ini </div>';
}
?>

