<?php empty( $app ) ? header('location:../homeadmin.php') : '' ; if(isset($_SESSION['level'])){ ?>

<html>
<head>
</head>

<body>

<?php if($_SESSION['level']!='admin'){
echo '<div class="alert alert-error"> Maaf Anda Harus Login sebagai level Admin terlebih dahulu untuk mengakses halaman ini </div>';//jika bukan admin jangan lanjut
die ('');
?>

<?php } ?>

<div style="text-align:justify;"><img src="../catatan.png" width="50" height="50" style="float:left; margin:0 9px 3px 0;" /><legend>Transaksi Perpustakaan</legend></h3>

<p>
	<a href="app/data_transaksi.php" class="btn btn-mini"><i class="btn btn-success btn-lg"> Data Transaksi</i></a>&nbsp;
	<a href="app/input_transaksi.php" class="btn btn-mini"><i class="btn btn-success btn-lg"> Input Transaksi</i></a>&nbsp;
    <a href="app/history_peminjaman.php" class="btn btn-mini"><i class="btn btn-success btn-lg"> History Peminjaman</i></a>&nbsp;
</p>

<p><b>Note : </b>Menu di atas merupakan control panel transaksi peminjaman buku, hanya admin yang diizinkan menggunakannya, mahasiswa hanya diperbolehkan meminjam buku perpustakaan maksimal 2 buku dengan batas peminjaman 7 hari, bila lewat dari batas peminjaman akan diberikan denda Rp.500/hari.</p>

<?php 
}else{
echo '<div class="alert alert-error"> Maaf Anda Harus Login terlebih dahulu untuk mengakses halaman ini </div>';
}
?>

</body>
</html>