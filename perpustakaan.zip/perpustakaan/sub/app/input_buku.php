

<?php 
session_start();

//untuk "login_multiuser" bisa diganti dan sesuaikan dengan folder project
//tujuan seperti dibuat menggunakan $_SERVER['HTTP_HOST'] agar hostname berubah sendiri secara dinamis

            include "../base-url.php";

isset ($_GET['app']) ? $app = $_GET['app'] : $app = 'admin';

?>

<?php  include "head_admin.php"?>

<?php if($_SESSION['level']!='admin'){
echo '<div class="alert alert-error"> Maaf Anda Harus Login sebagai level Admin terlebih dahulu untuk mengakses halaman ini </div>';//jika bukan admin jangan lanjut
die ('');
?>

<?php } ?>

     <div class="row">
          <div class="col-lg-12">
            <section class="panel">
              <header class="panel-heading">
							  <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Tambah Data Buku</button>
						  
              </header>
			  
			  

              <div class="panel-body">
			  
		
		
			
			            <form class="form-validate form-horizontal"  action="simpan_buku.php" method="post">
                    <div class="form-group ">
                      <label for="fullname" class="control-label col-lg-2">ID Buku<span class="required">*</span></label>
                      <div class="col-lg-10">
                        <input class=" form-control" name="id_buku" type="text" />
                      </div>
                    </div>
					  <div class="form-group ">
                      <label for="fullname" class="control-label col-lg-2">Judul Buku<span class="required">*</span></label>
                      <div class="col-lg-10">
                        <input class=" form-control" name="judul" type="text"/>
                      </div>
                    </div>
					
					
					 <div class="form-group ">
                      <label for="fullname" class="control-label col-lg-2">Tahun Terbit<span class="required">*</span></label>
                      <div class="col-lg-10">
                        <input class=" form-control" name="terbit" type="text"/>
                      </div>
                    </div>
					
					
					 <div class="form-group ">
                      <label for="fullname" class="control-label col-lg-2">Penerbit<span class="required">*</span></label>
                      <div class="col-lg-10">
                        <input class=" form-control" name="penerbit" type="text"/>
                      </div>
                    </div>
					
					
				
					     <div class="form-group">
                        <label class="control-label col-sm-4">Tanggal Update</label>
                        <div class="col-sm-6">
                          <input id="datepicker" type="text" name="tanggal"  size="16" class="form-control" >
                        </div>
                      </div>
					
					<div class="form-group ">
                      <label for="fullname" class="control-label col-lg-2">Jumlah Halaman<span class="required">*</span></label>
                      <div class="col-lg-10">
                        <input class=" form-control" name="halaman" type="text"/>
                      </div>
                    </div>
					
					
					 <div class="form-group ">
                      <label for="fullname" class="control-label col-lg-2">Jumlah Buku<span class="required">*</span></label>
                      <div class="col-lg-10">
                        <input class=" form-control" name="jumlah" type="text"/>
                      </div>
                    </div>
					
							
					<div class="form-group ">
                      <label for="fullname" class="control-label col-lg-2">Asal Buku<span class="required">*</span></label>
                      <div class="col-lg-10">
                        <input class=" form-control" name="peroleh" type="text"/>
                      </div>
                    </div>		
							
	
					
     
                    <div class="form-group">
                      <div class="col-lg-offset-2 col-lg-10">
                        <button class="btn btn-primary" type="submit">Save</button>
                        <button class="btn btn-primary" type="reset" value="Reset" onclick="return confirm('Reset data yang telah dimasukan?')">Reset</button>
                         <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                      </div>
                    </div>
                  </form>
			 </div>
			 
			 
			 
		 

			 </section>
			
			      </section>
          </div>
        </div>
			
			
			
			
			
			
			
			
			
			
			






<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Form Input Data</h4>
      </div>
      <div class="modal-body">



     
            <section class="panel">
              <div class="panel-body">
           
               
			            <form class="form-validate form-horizontal"  action="simpan_buku.php" method="post">
                    <div class="form-group ">
                      <label for="fullname" class="control-label col-lg-2">ID Buku<span class="required">*</span></label>
                      <div class="col-lg-10">
                        <input class=" form-control" name="id_buku" type="text" />
                      </div>
                    </div>
					
					 <div class="form-group ">
                      <label for="fullname" class="control-label col-lg-2">Judul Buku<span class="required">*</span></label>
                      <div class="col-lg-10">
                        <input class=" form-control" name="judul" type="text"/>
                      </div>
                    </div>
					
					
					 <div class="form-group ">
                      <label for="fullname" class="control-label col-lg-2">Tahun Terbit<span class="required">*</span></label>
                      <div class="col-lg-10">
                        <input class=" form-control" name="terbit" type="text"/>
                      </div>
                    </div>
					
					
					 <div class="form-group ">
                      <label for="fullname" class="control-label col-lg-2">Penerbit<span class="required">*</span></label>
                      <div class="col-lg-10">
                        <input class=" form-control" name="penerbit" type="text"/>
                      </div>
                    </div>
					
					
				
					     <div class="form-group">
                        <label class="control-label col-sm-4">Tanggal Update</label>
                        <div class="col-sm-6">
                          <input id="dp2" type="text" name="tanggal"  size="16" class="form-control" >
                        </div>
                      </div>
					
					<div class="form-group ">
                      <label for="fullname" class="control-label col-lg-2">Jumlah Halaman<span class="required">*</span></label>
                      <div class="col-lg-10">
                        <input class=" form-control" name="halaman" type="text"/>
                      </div>
                    </div>
					
					
					 <div class="form-group ">
                      <label for="fullname" class="control-label col-lg-2">Jumlah Buku<span class="required">*</span></label>
                      <div class="col-lg-10">
                        <input class=" form-control" name="jumlah" type="text"/>
                      </div>
                    </div>
					
							
					<div class="form-group ">
                      <label for="fullname" class="control-label col-lg-2">Asal Buku<span class="required">*</span></label>
                      <div class="col-lg-10">
                        <input class=" form-control" name="peroleh" type="text"/>
                      </div>
                    </div>		
							
	
					
     
                    <div class="form-group">
                      <div class="col-lg-offset-2 col-lg-10">
                        <button class="btn btn-primary" type="submit">Save</button>
                        <button class="btn btn-primary" type="reset" value="Reset" onclick="return confirm('Reset data yang telah dimasukan?')">Reset</button>
                         <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                      </div>
                    </div>
                  </form>
                </div>
          
            </section>
          </div>




	
      </div>
 
	  
	  
	
		
    </div>

  </div>
</div>





















   <script> 
    //options method for call datepicker
	                $('#datepicker').datepicker({ format: 'dd-mm-yyyy', autoclose: true, todayHighlight: true})
	                $('#dp2').datepicker({ format: 'dd-mm-yyyy', autoclose: true, todayHighlight: true})
    </script>
		
		
		    <script type="text/javascript" src="<?php echo $base_url;?>asset/js/bootstrap-datepicker2.js"></script>
		

		        <script src="http://localhost/perpustakaan/dashboard/js/jquery.js"></script>
         <script src="http://localhost/perpustakaan/dashboard/js/bootstrap.min.js"></script>
  <!-- nice scroll -->
        <script src="http://localhost/perpustakaan/dashboard/js/jquery.scrollTo.min.js"></script>
         <script src="http://localhost/perpustakaan/dashboard/js/jquery.nicescroll.js" type="text/javascript"></script>

  <!-- jquery ui -->
           <script src="http://localhost/perpustakaan/dashboard/js/jquery-ui-1.9.2.custom.min.js"></script>

  <!--custom checkbox & radio-->
             <script type="text/javascript" src="http://localhost/perpustakaan/dashboard/js/ga.js"></script>
  <!--custom switch-->
         <script src="http://localhost/perpustakaan/dashboard/js/bootstrap-switch.js"></script>
  <!--custom tagsinput-->
        <script src="http://localhost/perpustakaan/dashboard/js/jquery.tagsinput.js"></script>

  <!-- colorpicker -->

  <!-- bootstrap-wysiwyg -->
         <script src="http://localhost/perpustakaan/dashboard/js/jquery.hotkeys.js"></script>
             <script src="http://localhost/perpustakaan/dashboard/js/bootstrap-wysiwyg.js"></script>
               <script src="http://localhost/perpustakaan/dashboard/js/bootstrap-wysiwyg-custom.js"></script>
                <script src="http://localhost/perpustakaan/dashboard/js/moment.js"></script>
               <script src="http://localhost/perpustakaan/dashboard/js/bootstrap-colorpicker.js"></script>
                      <script src="http://localhost/perpustakaan/dashboard/js/daterangepicker.js"></script>
               <script src="http://localhost/perpustakaan/dashboard/js/bootstrap-datepicker.js"></script>
  <!-- ck editor -->
             <script type="text/javascript" src="http://localhost/perpustakaan/dashboard/assets/ckeditor/ckeditor.js"></script>
  <!-- custom form component script for this page-->
              <script src="http://localhost/perpustakaan/dashboard/js/form-component.js"></script>
  <!-- custome script for all page -->
               <script src="http://localhost/perpustakaan/dashboard/js/scripts.js"></script>
