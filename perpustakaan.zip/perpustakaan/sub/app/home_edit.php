<?php empty( $app ) ? header('location:../homeupdate.php') : '' ;?>
<p>
	          <a class="btn btn-success btn-sm" href="homeadmin.php" title="Bootstrap 3 themes generator"> Home Admin</a>
</p>
<div style="text-align: justify;"><b>Halaman Update Perpustakaan</b><br>
<i>Seorang admin perpustakaan bisa melakukan kegiatan-kegiatan yang bersangkutan dengan update data mahasiswa "user" dan data pengurus "admin" maupun data buku yaitu sebagai berikut : </i></div>
<ul>
<li>Memambahkan Data Mahasiswa, Data Pengurus dan Data Buku</li>
<li>Mengedit Data Mahasiswa, Data Pengurus dan Data Buku</li>
<li>Menghapus Data Mahasiswa, Data Pengurus dan Data Buku</li>
<li>Mencari Data Mahasiswa, Data Pengurus dan Data Buku</li>
</ul>
<br><p align="center"><img src="../book6.png" width="250" height="250"></br>
<br>

<div style="text-align: justify;"><b>Perhtian !!!</b><br>
<i>Seorang admin yang memasuki halaman ini harus mengikuti peraturuan perpustakaan berikut ini : </i>
<ol>
<li>Tidak boleh menambahkan seorang member, pengurus dan buku perpustakaan sembarangan, kecuali memang terdaftar di dalam mahasiswa UNSIKA.</li>
<li>Admin harus mengecek secara berkala data mahasiswa yang terdaftar, pengurus dan buku.</li>
<li>Admin tidak boleh sembarangan menghapus data mahasiswa perpustakaan, data pengurus dan juga buku.</li>
<li>Admin tidak boleh sembarangan mengedit data mahasiswa perpustakaan, data pengurus dan data buku, kecuali memang ada perubahan dan ada konfirmasi dari pihak terkait.</li>
<li>Seorang admin harus mengikuti prosedur perpustakaan.</li>
<li>Gunakan dengan maksimal fungsi update data untuk keperluan tertentu, misalnya dalam pencarian data mahasiswa, pengurus dan data buku yang terdaftar.</li>
<li>Bila ada admin yang melanggar ketentuan harus siap untuk diberhentikan.</li>
</ol>

</div>