<!DOCTYPE html>

<style>
* {
  box-sizing: border-box;
}

#myInput {
  background-image: url('/css/searchicon.png');
  background-position: 10px 10px;
  background-repeat: no-repeat;
  width: 100%;
  font-size: 16px;
  padding: 12px 20px 12px 40px;
  border: 1px solid #ddd;
  margin-bottom: 12px;
}


</style>


<?php
$pinjam		= date("d-m-Y");
$seminggu	= mktime(0,0,0,date("n"),date("j")+7,date("Y"));
$kembali  	= date("d-m-Y", $seminggu);
?>


<?php 
include('koneksi.php');
?>

<?php empty( $app ) ? header('location:../homeuser.php') : '' ; if(isset($_SESSION['level'])){?>

<?php if($_SESSION['level']!='user'){
echo '<div class="alert alert-error"> Maaf Anda Harus Login sebagai level user terlebih dahulu untuk mengakses halaman ini </div>';//jika bukan admin jangan lanjut
die ('');
?>

<?php } ?>

<p>
							  <a href="app/input_transaksi_buku.php" button type="button" class="btn btn-info btn-lg" data-toggle="modal" >Transaksi Pinjaman</button></a>

</p>

<div class="tab-content">
<input type="text" id="myInput" onkeyup="myFunction()" placeholder="Pencarian.." title="Type in a name">
                       <table id="myTable" class="table table-bordered table-condensed table-hover">
	<thead>
		<tr class="nowrap">
			<th align="left">ID Buku</th>
			<th align="left">Judul Buku</th>
			<th align="left">Tahun Terbit</th>
			<th align="left">Penerbit</th>
			<th align="left">Jumlah Halaman</th>
			<th align="left">Jumlah Buku</th>
			<th align="left">Asal Buku</th>
			<th align="left">Tanggal Update</th>
			<?php if($_SESSION['level']=='user'){?>
			<!--<th colspan = "2" align="center">Alat</th>-->
			<?php } ?>
		</tr>
	</thead>
		<?php
    $sql = "SELECT * FROM buku ORDER BY id_buku";
    foreach ($dbh->query($sql) as $data) :
	?>
	<tbody>
		<tr class="nowrap">
			<td><?php echo $data['id_buku'] ?></td>
			<td><?php echo $data['judul'] ?></td>
            <td><?php echo $data['terbit'] ?></td>
			<td><?php echo $data['penerbit'] ?></td>
            <td><?php echo $data['halaman'] ?></td>
			<td><?php echo $data['jumlah'] ?></td>
			<td><?php echo $data['peroleh'] ?></td>
			<td><?php echo $data['tanggal'] ?></td>
			<?php if($_SESSION['level']=='user'){?>
			<!--<td><a class="btn btn-primary btn-lg" href="app/edit_buku.php?id_buku=<?php echo $data['id_buku'] ?>" title="Edit"><i class="icon_plus_alt2"></i></a></td>
			<td><a class="btn btn-success" href="#"><i class="icon_check_alt2"></i></a></td>
			<td><a class="btn btn-danger btn-lg" href="app/hapus_buku.php?id_buku=<?php echo $data['id_buku'] ?>" title="Delete"  onClick="return confirm('Delete data buku dengan ID : <?php echo $data['id_buku'];?>');"> <i class="icon_close_alt2"></i></a></td>
			-->
			
			<?php } ?>
		</tr>
<?php
    endforeach;
?>
	</tbody>
</table>
<p><b>Note : </b>Data di atas merupakan data buku yang terdapat di dalam sistem perpustakaan, yang telah ditambahkan oleh seorang admin dan dilakukan penambahan buku secara berkala ketika ada buku baru yang terupdate, untuk menambahkan kapasitas buku bisa dilakukan pengeditan data jumlah buku.</p>
</div>
<?php 
}else{
echo '<div class="alert alert-error"> Maaf Anda Harus Login terlebih dahulu untuk mengakses halaman ini </div>';
}
?>




<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Form Input Pinjam Buku</h4>
      </div>
      <div class="modal-body">



     
            <section class="panel">
              <div class="panel-body">
           
                  <form class="form-validate form-horizontal"  action="input_transaksi_action_siswa.php" method="post">
						<input type="hidden" name="pinjam" value="<?php echo $pinjam; ?>">
						<input type="hidden" name="kembali" value="<?php echo $kembali; ?>">					
					 <div class="form-group">
                    <label class="control-label col-lg-2" for="inputSuccess">Data Peminjam</label>
                    <div class="col-lg-10">
                      <select type="text" name="peminjam" class="form-control input-lg m-bot15" >
					  		    <option value="" selected>NPM &amp; Nama Peminjam </option>
								

								<?php
				include "koneksi_transaksi.php";
				$qa=mysql_query("SELECT * from user WHERE username='".$_SESSION['username']."'", $konek);
				while ($peminjam=mysql_fetch_array($qa)) {
                echo "<option value='$peminjam[0].$peminjam[2]'>$peminjam[0]. $peminjam[2]</option>";
				}
				?>                     
                       </select>                   
                    </div>
                  </div>
				  
				  
				   <div class="form-group">
                    <label class="control-label col-lg-2" for="inputSuccess">Judul Buku</label>
                    <div class="col-lg-10">
                      <select type="text" name="buku" class="form-control input-lg m-bot15" >
					  		    <option value="" selected>Pilih Judul Buku </option>
								
				<?php
					include "koneksi_transaksi.php";
					$q=mysql_query("SELECT * FROM buku ORDER BY id_buku", $konek);
					while ($buku=mysql_fetch_array($q)) {
					echo "<option value='$buku[0].$buku[1]'>$buku[0]. $buku[1]</option>";
					}
					?>                    
                       </select>                   
                    </div>
                  </div>

					     <div class="form-group">
                        <label class="control-label col-sm-4">Tanggal Pinjam</label>
                        <div class="col-sm-6">
                          <input type="text" name="pinjam" value="<?php echo $pinjam ?>" size="16" class="form-control" >
                        </div>
                      </div>
					  
					   <div class="form-group">
                        <label class="control-label col-sm-4">Tanggal Kembali</label>
                        <div class="col-sm-6">
                          <input type="text" name="kembali"  value="<?php echo $kembali?>" size="16" class="form-control" >
                        </div>
                      </div>
					
							
				  <div class="form-group">
                          <label class="control-label col-sm-2">Keterangan</label>
                          <div class="col-sm-10">
                            <textarea class="form-control ckeditor" name="ket" rows="6"></textarea>
                          </div>
                        </div>

                    <div class="form-group">
                      <div class="col-lg-offset-2 col-lg-10">
                        <button class="btn btn-primary" type="submit">Save</button>
                        <button class="btn btn-primary" type="reset" value="Reset" onclick="return confirm('Reset data yang telah dimasukan?')">Reset</button>
                         <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                      </div>
                    </div>
                  </form>
                </div>
          
            </section>
          </div>




	
      </div>
 
	  
	  
	
		
    </div>

  </div>
</div>

<script>
function myFunction() {
  var input, filter, table, tr, td, i;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
</script>