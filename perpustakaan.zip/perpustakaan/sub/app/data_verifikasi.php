<?php 
session_start();
error_reporting(0);
//untuk "login_multiuser" bisa diganti dan sesuaikan dengan folder project
//tujuan seperti dibuat menggunakan $_SERVER['HTTP_HOST'] agar hostname berubah sendiri secara dinamis

include "../base-url.php";

isset ($_GET['app']) ? $app = $_GET['app'] : $app = 'admin';

?>

<?php
include "koneksi_transaksi.php";
include "transaksi_fungsi.php";

$query=mysql_query("SELECT * FROM transaksi WHERE status='Pending' ORDER BY id_transaksi", $konek);
?>



<?php  include "head_admin.php"?>



<?php if($_SESSION['level']!='admin'){
echo '<div class="alert alert-error"> Maaf Anda Harus Login sebagai level Admin terlebih dahulu untuk mengakses halaman ini </div>';//jika bukan admin jangan lanjut
die ('');
?>

<?php } ?>


<div class="tab-content">





          <div class="col-lg-12">
            <section class="panel">
              <header class="panel-heading">
               Data Transaksi Buku Perpustakaan
              </header>

              <table class="table table-striped table-advance table-hover">
                <tbody>
	
        <tr><td align="left">No</td>
		    <td align="left">Judul Buku</td>
			<td align="left">ID Buku</td>
			<td align="left">Nama Peminjam</td>
			<td align="left">ID Peminjam</td>
			<td align="left">Tgl. Pesan</td>
			<td align="left">Tgl. Kembali</td>
			<td align="left">Status</td>
			<td align="left">Keterangan</td>
			<td align="left">Denda</td>
			<td align="left">Action</td>

	    </tr>
	</tbody>
	<tbody>
<?php
$no=0;
while ($hasil=mysql_fetch_array($query)) {
$no++;
echo "<tr>
	  <td class='td-data'>$no</td>
      <td class='pinggir-data'>$hasil[1]</td>
	  <td class='td-data'>$hasil[2]</td>
	  <td class='td-data'>$hasil[3]</td>
	  <td class='td-data'>$hasil[4]</td>
	  <td class='td-data'>$hasil[5]</td>
	  <td class='td-data'>$hasil[6]</td>
	  <td class='td-data'>$hasil[7]</td>
	  <td class='td-data'>$hasil[8]</td>
	  <td class='td-data'>";

	    $tgl_dateline=$hasil['tgl_kembali'];
		$tgl_kembali=date('d-m-Y');
		$lambat=terlambat($tgl_dateline, $tgl_kembali);
		$denda=$lambat*$denda1;
		if ($lambat>0) {
		echo "<font color='red'>$lambat hari<br>(Rp $denda)</font>";
		}
		else {
		echo $lambat." hari";
		}
echo "</td>
	  <!--<td class='td-data'><a href='kembali_action.php?id_transaksi=$hasil[id_transaksi]&judul=$hasil[1]&denda=$denda'><i class='btn btn-danger btn-sm'>Kembali&nbsp;</i></a></td>-->
	  <td class='td-data'><a href='pinjam_action.php?id_transaksi=$hasil[id_transaksi]&judul=$hasil[1]&denda=$denda'><i class='btn btn-danger btn-sm'>Verifikasi&nbsp;</i></a></td>
	 <!-- <td class='td-data'><a href='perpanjang_action.php?id_transaksi=$hasil[id_transaksi]&judul=$hasil[1]&kembali=$hasil[6]&lambat=$lambat'><i class='btn btn-danger btn-sm'>Perpanjang&nbsp;</i></a></td>-->
	  </tr>";
}
?>
</tbody>
</table>
<a href="pdf_data_transaksi.php" class="btn btn-mini"><a class="btn btn-success btn-sm"> Print</a>&nbsp; <!--<a href="../homeadmin.php?app=transaksi" class="btn btn-mini"><i class="icon-th-large"></i> Transaksi</a>--->
<br>
<br>

<p><b>Note : </b>Data di atas merupakan data buku yang siap di perpanjang maupun siap data buku yang siap untuk dikembalikan, perpanjangan buku hanya boleh dilakukan 1x, batas waktu peminjaman 7 hari bila lewat dari batas itu akan dikenakan denda sebaesar Rp.500/hari.</p>
</div>







   <script> 
    //options method for call datepicker
	                $('#dp1').datepicker({ format: 'dd-mm-yyyy', autoclose: true, todayHighlight: true})
	                $('#dp2').datepicker({ format: 'dd-mm-yyyy', autoclose: true, todayHighlight: true})
    </script>
		
		
		    <script type="text/javascript" src="<?php echo $base_url;?>asset/js/bootstrap-datepicker2.js"></script>
		

		        <script src="http://localhost/perpustakaan/dashboard/js/jquery.js"></script>
         <script src="http://localhost/perpustakaan/dashboard/js/bootstrap.min.js"></script>
  <!-- nice scroll -->
        <script src="http://localhost/perpustakaan/dashboard/js/jquery.scrollTo.min.js"></script>
         <script src="http://localhost/perpustakaan/dashboard/js/jquery.nicescroll.js" type="text/javascript"></script>

  <!-- jquery ui -->
           <script src="http://localhost/perpustakaan/dashboard/js/jquery-ui-1.9.2.custom.min.js"></script>

  <!--custom checkbox & radio-->
             <script type="text/javascript" src="http://localhost/perpustakaan/dashboard/js/ga.js"></script>
  <!--custom switch-->
         <script src="http://localhost/perpustakaan/dashboard/js/bootstrap-switch.js"></script>
  <!--custom tagsinput-->
        <script src="http://localhost/perpustakaan/dashboard/js/jquery.tagsinput.js"></script>

  <!-- colorpicker -->

  <!-- bootstrap-wysiwyg -->
         <script src="http://localhost/perpustakaan/dashboard/js/jquery.hotkeys.js"></script>
             <script src="http://localhost/perpustakaan/dashboard/js/bootstrap-wysiwyg.js"></script>
               <script src="http://localhost/perpustakaan/dashboard/js/bootstrap-wysiwyg-custom.js"></script>
                <script src="http://localhost/perpustakaan/dashboard/js/moment.js"></script>
               <script src="http://localhost/perpustakaan/dashboard/js/bootstrap-colorpicker.js"></script>
                      <script src="http://localhost/perpustakaan/dashboard/js/daterangepicker.js"></script>
               <script src="http://localhost/perpustakaan/dashboard/js/bootstrap-datepicker.js"></script>
  <!-- ck editor -->
             <script type="text/javascript" src="http://localhost/perpustakaan/dashboard/assets/ckeditor/ckeditor.js"></script>
  <!-- custom form component script for this page-->
              <script src="http://localhost/perpustakaan/dashboard/js/form-component.js"></script>
  <!-- custome script for all page -->
               <script src="http://localhost/perpustakaan/dashboard/js/scripts.js"></script>
