

<style>
* {
  box-sizing: border-box;
}

#myInput {
  background-image: url('/css/searchicon.png');
  background-position: 10px 10px;
  background-repeat: no-repeat;
  width: 100%;
  font-size: 16px;
  padding: 12px 20px 12px 40px;
  border: 1px solid #ddd;
  margin-bottom: 12px;
}


</style>
<?php 
include('koneksi.php');
include('koneksi_transaksi.php');
include('transaksi_fungsi.php');

$query=mysql_query("SELECT * FROM transaksi WHERE status LIKE 'Pinjam' AND id_peminjam='".$_SESSION['username']."' ORDER BY id_transaksi", $konek);
?>
<html>
<body>
<?php empty( $app ) ? header('location:../homeuser.php') : '' ; if(isset($_SESSION['level'])){?>

<?php if($_SESSION['level']!='user'){
echo '<div class="alert alert-error"> Maaf Anda Harus Login sebagai level User terlebih dahulu untuk mengakses halaman ini </div>';//jika bukan user jangan lanjut
die ('');
?>

<?php } ?>




<?php 
}else{
echo '<div class="alert alert-error"> Maaf Anda Harus Login terlebih dahulu untuk mengakses halaman ini </div>';
}
?>
<br>
<div style="text-align:justify;"><img src="../status.png" width="50" height="50" style="float:left; margin:0 9px 3px 0;" /><legend>Status Peminjaman Buku</legend></h3>


    <div class="row">
          <div class="col-md-12">
            <section class="panel">
              <header class="panel-heading">
                <h3>Buttons</h3>

              </header>
              <div class="panel-body">
			  <input type="text" id="myInput" onkeyup="myFunction()" placeholder="Pencarian.." title="Type in a name">
                <table id="myTable" class="table table-bordered table-striped">

	<thead>
		<tr class="nowrap">
        <tr><td align="left">No</td>
		    <td align="left">Judul Buku</td>
			<td align="left">ID Buku</td>
			<td align="left">Nama Peminjam</td>
			<td align="left">ID Peminjam</td>
			<td align="left">Tgl. Pinjam</td>
			<td align="left">Tgl. Kembali</td>
			<td align="left">Status</td>
			<td align="left">Terlambat</td>
	    </tr>
	</thead>
	<tbody>
<?php
$no=0;
while ($hasil=mysql_fetch_array($query)) {
$no++;
echo "<tr>
	  <td class='td-data'>$no</td>
      <td class='pinggir-data'>$hasil[1]</td>
	  <td class='td-data'>$hasil[2]</td>
	  <td class='td-data'>$hasil[3]</td>
	  <td class='td-data'>$hasil[4]</td>
	  <td class='td-data'>$hasil[5]</td>
	  <td class='td-data'>$hasil[6]</td>
	  <td class='td-data'>$hasil[7]</td>
	  <td class='td-data'>";

	    $tgl_dateline=$hasil['tgl_kembali'];
		$tgl_kembali=date('d-m-Y');
		$lambat=terlambat($tgl_dateline, $tgl_kembali);
		$denda=$lambat*$denda1;
		if ($lambat>0) {
		echo "<font color='red'>$lambat hari<br>(Rp $denda)</font>";
		}
		else {
		echo $lambat." hari";
		}
echo "</td></tr>";
}
?>
</tbody>
</table>
<p><b>Note : </b>Data di atas merupakan status peminjaman buku perpustakaan sebagai pengingat siswa yang sedang meminjam buku perputakaan, perpanjangan buku hanya boleh dilakukan 1x, batas waktu peminjaman 7 hari bila lewat dari batas itu akan dikenakan denda sebaesar Rp.500/hari.</p>
</div>
</div>
</div>
</section>

<script>
function myFunction() {
  var input, filter, table, tr, td, i;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
</script>