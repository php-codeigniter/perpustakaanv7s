<?php
include 'koneksi.php';
if (isset($_GET['username'])) {
    $query = $dbh->query("SELECT * FROM user WHERE username = '$_GET[username]'");
    $data  = $query->fetch(PDO::FETCH_ASSOC);
} else {
    echo "NPM tidak tersedia, Silahkan Cek Ulang<br /><a href='http://localhost/Project/login_multiuser/homeadmin.php?app=data_user'>Kembali</a>";
    exit();
}

if ($data === false) {
    echo "NPM tidak ditemukan, Silahkan Lakukan Registrasi<br /><a href='http://localhost/Project/login_multiuser/homeadmin.php?app=data_user'>Kembali</a>";
    exit();
}
?>

<?php 
session_start();

//untuk "login_multiuser" bisa diganti dan sesuaikan dengan folder project
//tujuan seperti dibuat menggunakan $_SERVER['HTTP_HOST'] agar hostname berubah sendiri secara dinamis

$base_url = 'http://'.$_SERVER['HTTP_HOST'].'/Project/login_multiuser/';

isset ($_GET['app']) ? $app = $_GET['app'] : $app = 'admin';

?>
                 <?php include"head_admin.php" ?>


<?php if($_SESSION['level']!='admin'){
echo '<div class="alert alert-error"> Maaf Anda Harus Login sebagai level Admin terlebih dahulu untuk mengakses halaman ini </div>';//jika bukan admin jangan lanjut
die ('');
?>

<?php } ?>

        <div class="row">
          <div class="col-lg-12">
            <section class="panel">
              <header class="panel-heading">
        Edit Data Admin
              </header>
              <div class="panel-body">
			
			            <form class="form-validate form-horizontal"  action="edit_admin_action.php" method="post">
                    <div class="form-group ">
                      <label for="fullname" class="control-label col-lg-2">Username<span class="required">*</span></label>
                      <div class="col-lg-10">
                        <input class=" form-control" name="username" type="text" value="<?php echo $data['username']; ?>"/>
                      </div>
                    </div>
				<div class="form-group ">
                      <label for="password" class="control-label col-lg-2">Password <span class="required">*</span></label>
                      <div class="col-lg-10">
                        <input class="form-control " name="password" type="password" value="<?php echo $data['password']; ?>" />
                      </div>
                    </div>
					  <div class="form-group ">
                      <label for="fullname" class="control-label col-lg-2">Nama<span class="required">*</span></label>
                      <div class="col-lg-10">
                        <input class=" form-control" name="nama" type="text" value="<?php echo $data['nama']; ?>"/>
                      </div>
                    </div>
					
					 <div class="form-group">
                    <label class="control-label col-lg-2" for="inputSuccess">Jenis Kelamin</label>
                    <div class="col-lg-10">
            
					
                      <select type="text" name="jk" class="form-control input-lg m-bot15" value="<?php echo $data['jk']; ?>">
					  		    <option selected disabled>Pilih Jenis Kelamin</option>	
                                              <option>laki-Laki</option>
                                              <option>Perempuan</option>
                                             
                       </select>
                   
                    </div>
                  </div>
					
			                    <div class="form-group ">
                      <label for="fullname" class="control-label col-lg-2">Tempat Lahir<span class="required">*</span></label>
                      <div class="col-lg-10">
                        <input class=" form-control" id="tempat" name="tempat" type="text" value="<?php echo $data['tempat']; ?>"/>
                      </div>
                    </div>		
					
					     <div class="form-group">
                        <label class="control-label col-sm-4">Tanggal Lahir</label>
                        <div class="col-sm-6">
                          <input id="dp1" type="text" name="lahir"  size="16" class="form-control" value="<?php echo $data['lahir']; ?>">
                        </div>
                      </div>
					
							
					 <div class="form-group">
                    <label class="control-label col-lg-2" for="inputSuccess">Kelas</label>
                    <div class="col-lg-10">
            

                      <select type="text" name="fakultas" class="form-control input-lg m-bot15" value="<?php echo $data['fakultas']; ?>">
					  		    <option selected disabled>Pilih Kelas</option>	
                                              <option>1</option>
                                              <option>2</option>
                                              <option>3</option>
                                             
                       </select>
                   
                    </div>
                  </div>
					
					
						 <div class="form-group">
                    <label class="control-label col-lg-2" for="inputSuccess">Jurusan</label>
                    <div class="col-lg-10">
            

                      <select type="text" name="jurusan" class="form-control input-lg m-bot15" value="<?php echo $data['jurusan']; ?>">
					  		    <option selected disabled>Pilih Jurusan</option>	
                                              <option>IPA</option>
                                              <option>IPS</option>
                                         
                                             
                       </select>
                   
                    </div>
                  </div>
					
					    <div class="form-group ">
                      <label for="fullname" class="control-label col-lg-2">Angkatan<span class="required">*</span></label>
                      <div class="col-lg-10">
                        <input class=" form-control" name="tahun" type="text" value="<?php echo $data['tahun']; ?>" />
                      </div>
                    </div>
					
					
					
				    <div class="form-group ">
                      <label for="address" class="control-label col-lg-2">Address <span class="required">*</span></label>
                      <div class="col-lg-10">
                        <input class=" form-control" name="alamat" type="text" value="<?php echo $data['alamat']; ?>"/>
                      </div>
                    </div>
					
					    <div class="form-group ">
                      <label for="fullname" class="control-label col-lg-2">Email<span class="required">*</span></label>
                      <div class="col-lg-10">
                        <input class=" form-control" name="email" type="text" value="<?php echo $data['email']; ?>" />
                      </div>
                    </div>
					
					
					    <div class="form-group ">
                      <label for="fullname" class="control-label col-lg-2">Handphone<span class="required">*</span></label>
                      <div class="col-lg-10">
                        <input class=" form-control"  name="hp" type="text" value="<?php echo $data['hp']; ?>" />
                      </div>
                    </div>
					
					
					
						 <div class="form-group">
                    <label class="control-label col-lg-2" for="inputSuccess">Level </label>
                    <div class="col-lg-10">
            

                      <select type="text" name="level" class="form-control input-lg m-bot15" value="<?php echo $data['level']; ?>">
					  		    <option selected disabled>Pilih Level</option>	
                                              <option>admin</option>
                                              <option>user</option>
                                             
                       </select>
                   
                    </div>
           
					
					
					
					
					
     
                    <div class="form-group">
                      <div class="col-lg-offset-2 col-lg-10">
                        <button class="btn btn-primary" type="submit">Save</button>
                         <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                      </div>
                    </div>
                  </form>
			 </div>
			 </section>
			
			      </section>
          </div>
        </div>
			
			
			
			
			
			
			
			
			
			
			

























   <script> 
    //options method for call datepicker
	$('#dp1').datepicker({
         format: 'dd-mm-yyyy',
		 autoclose: true,
		 todayHighlight: true
	})
    </script>
		
		
		    <script type="text/javascript" src="<?php echo $base_url;?>asset/js/bootstrap-datepicker2.js"></script>
		

		        <script src="http://localhost/perpustakaan/dashboard/js/jquery.js"></script>
         <script src="http://localhost/perpustakaan/dashboard/js/bootstrap.min.js"></script>
  <!-- nice scroll -->
        <script src="http://localhost/perpustakaan/dashboard/js/jquery.scrollTo.min.js"></script>
         <script src="http://localhost/perpustakaan/dashboard/js/jquery.nicescroll.js" type="text/javascript"></script>

  <!-- jquery ui -->
           <script src="http://localhost/perpustakaan/dashboard/js/jquery-ui-1.9.2.custom.min.js"></script>

  <!--custom checkbox & radio-->
             <script type="text/javascript" src="http://localhost/perpustakaan/dashboard/js/ga.js"></script>
  <!--custom switch-->
         <script src="http://localhost/perpustakaan/dashboard/js/bootstrap-switch.js"></script>
  <!--custom tagsinput-->
        <script src="http://localhost/perpustakaan/dashboard/js/jquery.tagsinput.js"></script>

  <!-- colorpicker -->

  <!-- bootstrap-wysiwyg -->
         <script src="http://localhost/perpustakaan/dashboard/js/jquery.hotkeys.js"></script>
             <script src="http://localhost/perpustakaan/dashboard/js/bootstrap-wysiwyg.js"></script>
               <script src="http://localhost/perpustakaan/dashboard/js/bootstrap-wysiwyg-custom.js"></script>
                <script src="http://localhost/perpustakaan/dashboard/js/moment.js"></script>
               <script src="http://localhost/perpustakaan/dashboard/js/bootstrap-colorpicker.js"></script>
                      <script src="http://localhost/perpustakaan/dashboard/js/daterangepicker.js"></script>
               <script src="http://localhost/perpustakaan/dashboard/js/bootstrap-datepicker.js"></script>
  <!-- ck editor -->
             <script type="text/javascript" src="http://localhost/perpustakaan/dashboard/assets/ckeditor/ckeditor.js"></script>
  <!-- custom form component script for this page-->
              <script src="http://localhost/perpustakaan/dashboard/js/form-component.js"></script>
  <!-- custome script for all page -->
               <script src="http://localhost/perpustakaan/dashboard/js/scripts.js"></script>

