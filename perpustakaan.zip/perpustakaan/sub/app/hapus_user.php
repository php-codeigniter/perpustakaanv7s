<?php
include 'koneksi.php';
if (isset($_GET['username'])) {
    $dbh->exec("DELETE FROM user WHERE username = '$_GET[username]'");
}
header("location:../homeadmin.php?app=data_user")
?>