<?php empty( $app ) ? header('location:../homeadmin.php') : '' ;?>
<div style="text-align: justify;"><b>Halaman Admin Perpustakaan</b><br>
<i>Di dalam menu ini seorang admin perpustakaan bisa melakukan kegiatan-kegiatan yang bersangkutan dengan administrasi yaitu sebagai berikut : </i></div>
<ul>
<li>Melihat Data Admin</li>
<li>Melihat Data Siswa</li>
<li>Melakukan Transaksi Peminjaman &amp; Pengembalian Buku Perpustakaan dan Verifikasi Pesanan Siswa Via Online</li>
</ul>
<br><p align="center"><img src="../book5.jpg" width="250" height="250"></br>
<br>

<div style="text-align: justify;"><b>Perhtian !!!</b><br>
<i>Seorang admin harus mengikuti peraturuan perpustakaan berikut ini : </i>
<ol>
<li>Tidak boleh menambahkan seorang pengguna sembarangan.</li>
<li>Seorang admin harus tahu betul bagaimana mengoprasikan aplikasi.</li>
<li>Admin tidak boleh sembarangan menghapus data penting perpustakaan.</li>
<li>Untuk mengupdate data buku harus dilakukan secara berkala semenjak ada buku baru yang masuk.</li>
<li>Bila ada admin yang melanggar ketentuan harus siap untuk diberhentikan.</li>
</ol>

</div>
