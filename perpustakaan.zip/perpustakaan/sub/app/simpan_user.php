<?php
include 'koneksi.php';

if (isset($_POST)) {
    $sql = "INSERT INTO user VALUE ('$_POST[username]', '$_POST[password]', '$_POST[nama]', '$_POST[jk]', '$_POST[tempat]', '$_POST[lahir]', '$_POST[fakultas]', '$_POST[jurusan]', '$_POST[tahun]', '$_POST[alamat]', '$_POST[email]', '$_POST[hp]', '', '$_POST[level]')";
    $dbh->exec($sql);
}

header("location:../homeadmin.php?app=data_user");
?>