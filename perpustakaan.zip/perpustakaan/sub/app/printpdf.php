
<?php 
session_start();

//untuk "login_multiuser" bisa diganti dan sesuaikan dengan folder project
//tujuan seperti dibuat menggunakan $_SERVER['HTTP_HOST'] agar hostname berubah sendiri secara dinamis

include "../base-url.php";

isset ($_GET['app']) ? $app = $_GET['app'] : $app = 'user';

?>
<?php 
include('koneksi_transaksi.php');


$query=mysql_query("SELECT * FROM transaksi WHERE status LIKE 'Pending' AND id_peminjam='".$_SESSION['username']."' ORDER BY id_transaksi", $konek);
?>






<?php if($_SESSION['level']!='user'){
echo '<div class="alert alert-error"> Maaf Anda Harus Login sebagai level Admin terlebih dahulu untuk mengakses halaman ini </div>';//jika bukan admin jangan lanjut
die ('');
?>

<?php } ?>










<style>
 table{
  border:silver 1px solid;
 }
 table td{
  border-bottom:silver 1px solid;
  border-right:silver 1px solid;
  padding:0 0 0 5px;
 }
</style>
<table cellpadding="0" cellspacing="0" style="font-family:Verdana, Geneva, sans-serif">
  <!--DWLayoutTable-->
  <tr>
    <td height="25" colspan="7" align="center"><strong>DAFTAR MAHASISWA</strong></td>
  </tr>
  <tr>
    <td height="25" align="center" style="background-color:#CCC"><strong>NO</strong></td>
    <td width="100" align="center" style="background-color:#CCC"><strong>NIS</strong></td>
    <td width="250" align="center" style="background-color:#CCC"><strong>NAMA</strong></td>
    <td width="150" align="center" style="background-color:#CCC"><strong>ALAMAT</strong></td>
    <td width="150" align="center" style="background-color:#CCC"><strong>TGL LAHIR</strong></td>
    <td width="150" align="center" style="background-color:#CCC"><strong>TELEPON</strong></td>
     <td width="100" align="center" style="background-color:#CCC"><strong>ANGKATAN</strong></td>
  </tr>
<?php
$nomor = 1;
while($data = mysql_fetch_array($query)){
$kode = $data['id_transaksi']; // ambil nis siswa (unik)
?>
  <tr>
    <td width="38" height="25" valign="middle"><?php echo $nomor; ?></td>
    <td valign="middle"><?php echo $data['id_transaksi']; ?></td>
    <td valign="middle"><?php echo $data['nama_peminjam']; ?></td>

 <!-- BUAT LINK POP UP KE HALAMAN PDF KONVERTER SEPERTI PADA CONTOH BERIKUT -->

   </tr>
<?php
$nomor++;
}
?>
</table>

</body>
</html><!-- Akhir halaman HTML yang akan di konvert -->
<?php
$filename="mhs-".$kode.".pdf"; //ubah untuk menentukan nama file pdf yang dihasilkan nantinya
//==========================================================================================================
//Copy dan paste langsung script dibawah ini,untuk mengetahui lebih jelas tentang fungsinya silahkan baca-baca tutorial tentang HTML2PDF
//==========================================================================================================
$content = ob_get_clean();
$content = '<page style="font-family: freeserif">'.nl2br($content).'</page>';
 require_once(dirname(__FILE__).'../pdf/html2pdf/html2pdf.class.php');
 try
 {
  $html2pdf = new HTML2PDF('P','A4','en', false, 'ISO-8859-15',array(30, 0, 20, 0));
  $html2pdf->setDefaultFont('Arial');
  $html2pdf->writeHTML($content, isset($_GET['vuehtml']));
  $html2pdf->Output($filename);
 }
 catch(HTML2PDF_exception $e) { echo $e; }
?>