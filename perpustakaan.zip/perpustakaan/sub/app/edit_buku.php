<?php
error_reporting(0);
include 'koneksi_buku.php';
?>

<?php 
$id = $_GET['id_buku'];

$query = mysql_query("select * from buku where id_buku='$id'") or die(mysql_error());

$data = mysql_fetch_array($query);
?>

<?php 
session_start();

//untuk "login_multiuser" bisa diganti dan sesuaikan dengan folder project
//tujuan seperti dibuat menggunakan $_SERVER['HTTP_HOST'] agar hostname berubah sendiri secara dinamis

$base_url = 'http://'.$_SERVER['HTTP_HOST'].'/Project/login_multiuser/';

isset ($_GET['app']) ? $app = $_GET['app'] : $app = 'admin';

?>
   <?php include"head_admin.php" ?>

<?php if($_SESSION['level']!='admin'){
echo '<div class="alert alert-error"> Maaf Anda Harus Login sebagai level Admin terlebih dahulu untuk mengakses halaman ini </div>';//jika bukan admin jangan lanjut
die ('');
?>

<?php } ?>




 <div class="row">
          <div class="col-lg-12">
            <section class="panel">
              <header class="panel-heading">
							  <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#">Edit Buku</button>
						  
              </header>
			  
			  

              <div class="panel-body">
			  
		
		
			
			            <form class="form-validate form-horizontal"  action="edit_buku_action.php" method="post">
                    <div class="form-group ">
                      <div class="col-lg-10">
                        <input class=" form-control" name="id_buku" type="hidden"  value="<?php echo $id; ?>" />
                      </div>
                    </div>
					  <div class="form-group ">
                      <label for="fullname" class="control-label col-lg-2">Judul Buku<span class="required">*</span></label>
                      <div class="col-lg-10">
                        <input class=" form-control" name="judul" type="text" value="<?php echo $data['judul']; ?>" />
                      </div>
                    </div>
					
					
					 <div class="form-group ">
                      <label for="fullname" class="control-label col-lg-2">Tahun Terbit<span class="required">*</span></label>
                      <div class="col-lg-10">
                        <input class=" form-control" name="terbit" type="text" value="<?php echo $data['terbit']; ?>" />
                      </div>
                    </div>
					
					
					 <div class="form-group ">
                      <label for="fullname" class="control-label col-lg-2">Penerbit<span class="required">*</span></label>
                      <div class="col-lg-10">
                        <input class=" form-control" name="penerbit" type="text" value="<?php echo $data['penerbit']; ?>"/>
                      </div>
                    </div>
					
					

					
					<div class="form-group ">
                      <label for="fullname" class="control-label col-lg-2">Jumlah Halaman<span class="required">*</span></label>
                      <div class="col-lg-10">
                        <input class=" form-control" name="halaman" type="text" value="<?php echo $data['halaman']; ?>"/>
                      </div>
                    </div>
					
					
					 <div class="form-group ">
                      <label for="fullname" class="control-label col-lg-2">Jumlah Buku<span class="required">*</span></label>
                      <div class="col-lg-10">
                        <input class=" form-control" name="jumlah" type="text" value="<?php echo $data['jumlah']; ?>"/>
                      </div>
                    </div>
					
							
					<div class="form-group ">
                      <label for="fullname" class="control-label col-lg-2">Asal Buku<span class="required">*</span></label>
                      <div class="col-lg-10">
                        <input class=" form-control" name="peroleh" type="text" value="<?php echo $data['peroleh']; ?>"/>
                      </div>
                    </div>		
							
							
							
											
					     <div class="form-group">
                        <label class="control-label col-sm-4">Tanggal Update</label>
                        <div class="col-sm-6">
                          <input id="dp1" type="text" name="tanggal"  size="16" class="form-control" value="<?php echo $data['tanggal']; ?>">
                        </div>
                      </div>
	
					
     
                    <div class="form-group">
                      <div class="col-lg-offset-2 col-lg-10">
                        <button class="btn btn-primary" type="submit">Save</button>
                        <button class="btn btn-primary" type="reset" value="Reset" onclick="return confirm('Reset data yang telah dimasukan?')">Reset</button>
                         <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                      </div>
                    </div>
                  </form>
			 </div>
			 
			 
			 
		 

			 </section>
			
			      </section>
          </div>
        </div>
			
</div>





















   <script> 
    //options method for call datepicker
	                $('#dp1').datepicker({ format: 'dd-mm-yyyy', autoclose: true, todayHighlight: true})
    </script>
		
		
		    <script type="text/javascript" src="<?php echo $base_url;?>asset/js/bootstrap-datepicker2.js"></script>
		

		        <script src="http://localhost/perpustakaan/dashboard/js/jquery.js"></script>
         <script src="http://localhost/perpustakaan/dashboard/js/bootstrap.min.js"></script>
  <!-- nice scroll -->
        <script src="http://localhost/perpustakaan/dashboard/js/jquery.scrollTo.min.js"></script>
         <script src="http://localhost/perpustakaan/dashboard/js/jquery.nicescroll.js" type="text/javascript"></script>

  <!-- jquery ui -->
           <script src="http://localhost/perpustakaan/dashboard/js/jquery-ui-1.9.2.custom.min.js"></script>

  <!--custom checkbox & radio-->
             <script type="text/javascript" src="http://localhost/perpustakaan/dashboard/js/ga.js"></script>
  <!--custom switch-->
         <script src="http://localhost/perpustakaan/dashboard/js/bootstrap-switch.js"></script>
  <!--custom tagsinput-->
        <script src="http://localhost/perpustakaan/dashboard/js/jquery.tagsinput.js"></script>

  <!-- colorpicker -->

  <!-- bootstrap-wysiwyg -->
         <script src="http://localhost/perpustakaan/dashboard/js/jquery.hotkeys.js"></script>
             <script src="http://localhost/perpustakaan/dashboard/js/bootstrap-wysiwyg.js"></script>
               <script src="http://localhost/perpustakaan/dashboard/js/bootstrap-wysiwyg-custom.js"></script>
                <script src="http://localhost/perpustakaan/dashboard/js/moment.js"></script>
               <script src="http://localhost/perpustakaan/dashboard/js/bootstrap-colorpicker.js"></script>
                      <script src="http://localhost/perpustakaan/dashboard/js/daterangepicker.js"></script>
               <script src="http://localhost/perpustakaan/dashboard/js/bootstrap-datepicker.js"></script>
  <!-- ck editor -->
             <script type="text/javascript" src="http://localhost/perpustakaan/dashboard/assets/ckeditor/ckeditor.js"></script>
  <!-- custom form component script for this page-->
              <script src="http://localhost/perpustakaan/dashboard/js/form-component.js"></script>
  <!-- custome script for all page -->
               <script src="http://localhost/perpustakaan/dashboard/js/scripts.js"></script>
