<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Selamat Datang</title>
<link rel="stylesheet" href="awan.css">
<link href="awan_site.css" rel="stylesheet">
<link rel="shortcut icon" type="image/x-icon" href="book.ico"/>

<style>
#para1
{
font-family:"Times New Roman";
}
</style>

</head>

<body>
<div id="header">
<div class="awan no1"></div>
<div class="awan no2"></div>
<div class="awan no3"></div>
<div class="awan no4"></div>
<div class="awan no5"></div>
<div class="bulan"></div>

<h1><p id="para1">Perpustakaan Universitas Singaperbangsa Karawang</h1>
</div>
<div class="main">
<p><h2> <font face="Times New Roman" color="gold"> Perpustakaan Universitas Singaperbangsa Seharusnya Sudah Memiliki Sistem Online Berbasis WEB Bahasa Pemrograman PHP dengan Database MySQL dalam Memanajemen Proses Administrasi Pinjam dan Mengembalikan Buku dari Perpustakaan.</h2></p>
<br>
<i><h3> <font face="Times New Roman" color="black"> Untuk melanjutkan Silahkan Klik "Menu Home Perpustakaan" di bawah ini.</h3></i>
<br>
<p><font size="5" face="Times New Roman"><a href="login_multiuser/index.php">Menu Home Perpustakaan</a></p>
<br>
<br>
 <p><b><img src="logo.png" width="40" height="40" /><font size="4" face="Times New Roman" align="left"> Copyright &copy;<font size="4" face="Times New Roman" align="left"><a href="http://www.materi-it.com/"> Materi Teknik Informatika </a>2014 - <?php echo date('Y') ?></b></p>
</div>

</body>
</html>