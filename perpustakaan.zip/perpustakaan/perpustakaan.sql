-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 30, 2018 at 04:55 AM
-- Server version: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `perpustakaan`
--

-- --------------------------------------------------------

--
-- Table structure for table `buku`
--

CREATE TABLE IF NOT EXISTS `buku` (
  `id_buku` int(100) NOT NULL,
  `judul` varchar(30) NOT NULL,
  `terbit` varchar(30) NOT NULL,
  `penerbit` varchar(30) NOT NULL,
  `halaman` varchar(30) NOT NULL,
  `jumlah` int(100) NOT NULL,
  `peroleh` varchar(30) NOT NULL,
  `tanggal` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `buku`
--

INSERT INTO `buku` (`id_buku`, `judul`, `terbit`, `penerbit`, `halaman`, `jumlah`, `peroleh`, `tanggal`) VALUES
(1001, 'Komputer Grafik', '2014', 'Erlangga', '250', 16, 'Gramedia', '19-06-2014'),
(1002, 'Metodologi Penelitian', '2014', 'Erlangga', '250', 19, 'Toko Buku AA', '19-06-2014'),
(1003, 'Multimedia', '2014', 'Erlangga', '300', 16, 'Salemba', '19-06-2014'),
(1004, 'Pemrograman Visual', '2014', 'Erlangga', '300', 26, 'Toko Buku AA', '19-06-2014'),
(1005, 'Sistem Pakar', '2014', 'Erlangga', '250', 32, 'Salemba', '19-06-2014');

-- --------------------------------------------------------

--
-- Table structure for table `kas`
--

CREATE TABLE IF NOT EXISTS `kas` (
`id_kas` int(100) NOT NULL,
  `tgl` varchar(30) NOT NULL,
  `denda` bigint(100) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `kas`
--

INSERT INTO `kas` (`id_kas`, `tgl`, `denda`) VALUES
(2, '25-04-2018', 5000);

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE IF NOT EXISTS `transaksi` (
`id_transaksi` int(100) NOT NULL,
  `judul_buku` varchar(250) NOT NULL,
  `id_buku` varchar(30) NOT NULL,
  `nama_peminjam` varchar(100) NOT NULL,
  `id_peminjam` varchar(100) NOT NULL,
  `tgl_pinjam` varchar(15) NOT NULL,
  `tgl_kembali` varchar(15) NOT NULL,
  `status` varchar(10) NOT NULL,
  `ket` varchar(100) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`id_transaksi`, `judul_buku`, `id_buku`, `nama_peminjam`, `id_peminjam`, `tgl_pinjam`, `tgl_kembali`, `status`, `ket`) VALUES
(1, 'Multimedia', '1003', 'Wawan', '12345', '25-04-2018', '02-05-2018', 'Kembali', '1x'),
(2, 'Komputer Grafik', '1001', 'Wawan', '12345', '25-04-2018', '09-05-2018', 'Pinjam', '1x');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `username` varchar(100) NOT NULL,
  `password` varchar(30) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `jk` varchar(30) NOT NULL,
  `tempat` varchar(30) NOT NULL,
  `lahir` varchar(30) NOT NULL,
  `fakultas` varchar(30) NOT NULL,
  `jurusan` varchar(30) NOT NULL,
  `tahun` varchar(30) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `hp` varchar(30) NOT NULL,
  `foto` varchar(30) NOT NULL,
  `level` enum('admin','user') NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`username`, `password`, `nama`, `jk`, `tempat`, `lahir`, `fakultas`, `jurusan`, `tahun`, `alamat`, `email`, `hp`, `foto`, `level`) VALUES
('admin', 'admin', 'Admin-Tian', 'L', 'Jakarta', '24-09-1992', 'Fakultas Ilmu Komputer', 'Teknik Informatika S-1', '2011', 'Cikampek', 'septian.fasilkom@gmail.com', '08997206535', '', 'admin'),
('user', 'user', 'User-Tian', 'L', 'Jakarta', '24-09-1992', 'Fakultas Ilmu Komputer', 'Teknik Informatika S-1', '2011', 'Cikampek', 'septian.fasilkom@gmail.com', '08997206535', 'Tianchan Studio.jpg', 'user'),
('12345', '12345', 'Wawan', 'Perempuan', 'palopo', '04-21-2018', '1', 'IPA', '1979', 'Palopo KOTA', 'aans@gmail.com', '0889874837843', '', 'user'),
('', '', '', '', '', '', '', '', '', '', '', '', '', ''),
('12343454545', 'wawan', 'sdasdas', 'laki-Laki', 'sadsad', '04-25-2018', '2', 'IPS', '1990', 'palopo', 'sdsa@gmail.com', '456456546754', '', 'admin'),
('asadas5', '1213246', 'sdfsdfsd', 'Perempuan', 'fdfds', '04-17-2018', '3', 'IPA', 'dff', 'dfd', '4sd@gmail.com', '08898748378455', '', 'admin'),
('asfsdfdsfdsf', '2323424', 'Wawan', 'laki-Laki', 'dsadas', '04-11-2018', '1', 'IPA', '1988', 'palopo', 'aansakti777@gmail.com', '0889874837656', '', 'admin'),
('sdfds', 'dsfdsf', 'ddf', 'laki-Laki', 'dfds', '04-17-2018', '3', '', 'dfds', 'tt', 'bacokawan@gmail.com', 'dfd', '', 'admin'),
('sdfgdfgdfg', '45435436gfdg', '', 'laki-Laki', 'palopo', '04-09-2018', '1', 'IPA', 'dffd', 'fdg', 'bacokawan@gmail.com', 'tytr', '', 'admin'),
('545646', 'gff', 'sakti', 'L', 'fsdf', '28-03-2018', 'Fakultas Ilmu Sosial dan Ilmu ', 'Pendidikan Agama Islam S-1', '1979', 'tt', 'your@email.com', '0889874837843', '', 'admin'),
('akmal', '12243v', 'akmal', 'laki-Laki', 'palop', '04-03-2018', '2', 'IPA', '1979', 'tt', 'bacokawan@gmail.com', '0889874837843', '', 'user'),
('adit', '121423434', 'adit', 'laki-Laki', 'palopo', '2018-04-10', '1', 'IPA', 'dasd', 'sds', 'sdsa@gmail.com', 'sdfds', '', 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `buku`
--
ALTER TABLE `buku`
 ADD PRIMARY KEY (`id_buku`), ADD KEY `id_buku` (`id_buku`);

--
-- Indexes for table `kas`
--
ALTER TABLE `kas`
 ADD PRIMARY KEY (`id_kas`), ADD KEY `id_transaksi` (`id_kas`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
 ADD PRIMARY KEY (`id_transaksi`), ADD KEY `nama_peminjam` (`nama_peminjam`), ADD KEY `nama_peminjam_2` (`nama_peminjam`), ADD KEY `nama_peminjam_3` (`nama_peminjam`), ADD KEY `nama_peminjam_4` (`nama_peminjam`), ADD KEY `id_peminjam` (`id_peminjam`), ADD KEY `id_buku` (`id_buku`), ADD KEY `id_transaksi` (`id_transaksi`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
 ADD PRIMARY KEY (`username`), ADD KEY `nama` (`nama`), ADD KEY `nama_2` (`nama`), ADD KEY `nama_3` (`nama`), ADD KEY `nama_4` (`nama`), ADD KEY `username` (`username`), ADD KEY `username_2` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `kas`
--
ALTER TABLE `kas`
MODIFY `id_kas` int(100) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `transaksi`
--
ALTER TABLE `transaksi`
MODIFY `id_transaksi` int(100) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
