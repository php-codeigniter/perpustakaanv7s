<?php empty( $app ) ?  : '' ;

isset ($_SESSION['level']) ? $ap = $_SESSION['level'] : $ap = 'admin';
isset ($_SESSION['level']) ? $ap1 = $_SESSION['level'] : $ap1 = 'user';
?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="Creative - Bootstrap 3 Responsive Admin Template">
  <meta name="author" content="GeeksLabs">
  <meta name="keyword" content="Creative, Dashboard, Admin, Template, Theme, Bootstrap, Responsive, Retina, Minimal">
  <link rel="shortcut icon" href="img/favicon.png">

  <title>Sistem Informasi Perpustakaan SMK 2 Palopo</title>

  <!-- Bootstrap CSS -->
                <link href="http://localhost/perpustakaan/dashboard/css/bootstrap.min.css" rel="stylesheet">
  <!-- bootstrap theme -->
         <link href="http://localhost/perpustakaan/dashboard/css/bootstrap-theme.css" rel="stylesheet">
  <!--external css-->
  <!-- font icon -->
              <link href="http://localhost/perpustakaan/dashboard/css/elegant-icons-style.css" rel="stylesheet" />
              <link href="http://localhost/perpustakaan/dashboard/css/font-awesome.css" rel="stylesheet" />
  <!-- Custom styles -->
                <link href="http://localhost/perpustakaan/dashboard/css/style.css" rel="stylesheet">
            <link href="http://localhost/perpustakaan/dashboard/css/style-responsive.css" rel="stylesheet" />

  <!-- HTML5 shim and Respond.js IE8 support of HTML5 -->
  <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->

    <!-- =======================================================
      Theme Name: NiceAdmin
      Theme URL: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/
      Author: BootstrapMade
      Author URL: https://bootstrapmade.com
    ======================================================= -->
</head>

<body class="login-img3-body">

  <div class="container">
<?php 
if (isset($_SESSION['level'])){
if ($ap == 'admin'){
header("Location:homeadmin.php");
	}
else if ($ap1 == 'user'){
header("Location:homeuser.php");
	}
}
?>

<?php
if(isset($_SESSION['register'])):
$pesan = ($_SESSION['register']== 1)?'&nbsp;Data Akun Perpustakaan telah berhasil dibuat, silahkan lakukan Login untuk melanjutkan.' : '&nbsp;Daftar Akun Perpustakaan gagal dibuat silahkan ulangi lagi.'
?>

<div class="alert alert-success">
<button type="button" class="close" data-dismiss="alert">
<i class="icon-remove"></i></button>
<i class="icon-ok"></i>
<?php echo $pesan; ?>

<?php {unset($_SESSION['register']);} ?>

</div>

<?php
endif;
?>
    <form class="login-form" method="POST" action="cek_login.php">
      <div class="login-wrap">
        <p class="login-img"><i class="icon_lock_alt"></i></p>
				<tr><?php if(isset($_SESSION['error'])){?>
			<td colspan="3"><div class="alert alert-error"><a class="close" data-dismiss="alert" href="#">x</a>
			<?php echo $_SESSION['error']; unset($_SESSION['error']);}?></td>
		</tr>
        <div class="input-group">
          <span class="input-group-addon"><i class="icon_profile"></i></span>
          <input type="text" class="form-control" placeholder="Username" name="username" autofocus>
        </div>
        <div class="input-group">
          <span class="input-group-addon"><i class="icon_key_alt"></i></span>
          <input type="password" class="form-control" placeholder="Password" name="password" required>
        </div>
        <label class="checkbox">
                <input type="checkbox" value="remember-me"> Remember me
                <span class="pull-right"> <a href="#"> Forgot Password?</a></span>
            </label>
        <button class="btn btn-primary btn-lg btn-block" type="submit">Login</button>
        <button class="btn btn-info btn-lg btn-block" type="submit">Signup</button>
      </div>
    </form>
    <div class="text-right">
      <div class="credits">
          <!--
            All the links in the footer should remain intact.
            You can delete the links only if you purchased the pro version.
            Licensing information: https://bootstrapmade.com/license/
            Purchase the pro version form: https://bootstrapmade.com/buy/?theme=NiceAdmin
          -->
        </div>
    </div>
  </div>


</body>

</html>
